# Copyright 2024 NIMBUTECH S.A.S
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError


import base64
import re
import fitz 


import logging
_logger = logging.getLogger(__name__)


style_css_custom = {
    'green':""" background-color: green;
                            border: 1px solid rgba(27, 31, 35, .15);
                            border-radius: 6px;
                            box-shadow: rgba(27, 31, 35, .1) 0 1px 0;
                            box-sizing: border-box;
                            color: #fff;                            
                            font-family: -apple-system,system-ui,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji";
                            font-size: 14px;
                            font-weight: 600;
                            line-height: 20px;
                            padding: 6px 16px;                            
                            text-align: center;
                            text-decoration: none;
                            vertical-align: middle;
                            white-space: nowrap;""",
    'gray':""" background-color: gray;
                            border: 1px solid rgba(27, 31, 35, .15);
                            border-radius: 6px;
                            box-shadow: rgba(27, 31, 35, .1) 0 1px 0;
                            box-sizing: border-box;
                            color: #000;                            
                            font-family: -apple-system,system-ui,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji";
                            font-size: 14px;
                            font-weight: 600;
                            line-height: 20px;
                            padding: 6px 16px;                            
                            text-align: center;
                            text-decoration: none;
                            vertical-align: middle;
                            white-space: nowrap;""",
    'red':""" background-color: red;
                            border: 1px solid rgba(27, 31, 35, .15);
                            border-radius: 6px;
                            box-shadow: rgba(27, 31, 35, .1) 0 1px 0;
                            box-sizing: border-box;
                            color: #fff;                            
                            font-family: -apple-system,system-ui,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji";
                            font-size: 14px;
                            font-weight: 600;
                            line-height: 20px;
                            padding: 6px 16px;                            
                            text-align: center;
                            text-decoration: none;
                            vertical-align: middle;
                            white-space: nowrap;""",
}



class AccountMove(models.Model):
    _inherit= 'account.move'
    acuse_state_badge = fields.Html(string="Acuse de recibo", compute='_compute_acuse_state_badge', readonly=True)
    reclamo_state_badge = fields.Html(string="Reclamo de la Factura", compute='_compute_reclamo_state_badge', readonly=True)
    recibo_state_badge = fields.Html(string="Recibo del bien y/o servicio", compute='_compute_recibo_state_badge', readonly=True)
    tacita_state_badge = fields.Html(string="Aceptación Tácita", compute='_compute_tacita_state_badge', readonly=True)
    expresa_state_badge = fields.Html(string="Aceptación expresa", compute='_compute_expresa_state_badge', readonly=True)


    acuse_block = fields.Boolean(string="Estado Acuse en la DIAN OK",default=False)
    reclamo_block = fields.Boolean(string="Estado Reclamo en la DIAN OK",default=False)
    recibo_block = fields.Boolean(string="Estado Recibido en la DIAN OK",default=False)
    tacita_block = fields.Boolean(string="Estado Tacita en la DIAN OK",default=False)
    expresa_block = fields.Boolean(string="Estado Expresa en la DIAN OK",default=False)


    acuse_rechazo = fields.Boolean(string="Estado Acuse en la DIAN OK")
    reclamo_rechazo = fields.Boolean(string="Estado Reclamo en la DIAN OK")
    recibo_rechazo = fields.Boolean(string="Estado Recibido en la DIAN OK")
    tacita_rechazo = fields.Boolean(string="Estado Tacita en la DIAN OK")
    expresa_rechazo = fields.Boolean(string="Estado Expresa en la DIAN OK")


    exp_invoice_file = fields.Binary(string='Factura proveedor')
    original_filename = fields.Char(string='Nombre Original del Archivo')
    acuse_recibo_id = fields.Many2many('acuse.recibo',string='Acuse recibo')
    acuse_journal_id = fields.Many2one('account.journal', string="Diario")


    set_acuse_recibo_ok = fields.Boolean(string='Acuse configurado',default=False)
    set_acuse_values_ok = fields.Boolean(string='Acuse con valores',default=False)
    send_acuse_dian_ok = fields.Boolean(string='Acuse enviado',default=False)
    
    invoice_cufe = fields.Char(string="CUFE")

    tipo_documento = fields.Selection([
        ('01', 'Factura electrónica de venta'),
        ('03', 'Instrumento electrónico de transmisión – tipo 03'),
        ('04', 'Factura electrónica de Venta ‐ tipo 04'),
        ('91', 'Nota Crédito'),
        ('92', 'Nota Débito'),
        ('96', 'Eventos (AplicationResponse)')
    ], string='Tipo de Documento',default='01')

    tipo_evento_radian = fields.Selection([
        ('030', 'Acuse de recibo de Factura Electrónica de Venta'),
        ('031', 'Reclamo de la Factura Electrónica de Venta'),
        ('032', 'Recibo del bien y/o prestación del servicio'),
        ('033', 'Aceptación Tácita'),
        ('034', 'Aceptación expresa')
    ], string='Tipo de Evento RADIAN',default='030')

    tipo_de_rechazo_reclamo = fields.Selection([
        ('1', 'Documento con inconsistencias'),
        ('2', 'Mercancía no entregada totalmente'),
        ('3', 'Mercancía no entregada parcialmente'),
        ('4', 'Servicio no prestado')
    ], string='Tipo de Reclamo')



    @api.depends('acuse_block')
    def _compute_acuse_state_badge(self):
        for record in self:
            style = ''
            text = ''
            if record.acuse_block == True :
                style = style_css_custom['green']
                text = 'Aceptado'
            else:
                if record.acuse_rechazo == False:
                    style = style_css_custom['gray']
                    text = 'Pendiente'  
                else:
                    style = style_css_custom['red']
                    text = 'Rechazado'  
            record.acuse_state_badge = f"""
                <div style="width: 100px; text-align: center; {style} color: white;">
                    <span style="display: block;">{text}</span>
                </div>
            """


    @api.depends('reclamo_block')
    def _compute_reclamo_state_badge(self):
        for record in self:
            style = ''
            text = ''
            if record.reclamo_block == True :
                style = style_css_custom['green']
                text = 'Aceptado'
            else:
                if record.reclamo_rechazo == False:
                    style = style_css_custom['gray']
                    text = 'Pendiente'  
                else:
                    style = style_css_custom['red']
                    text = 'Rechazado'         
            record.reclamo_state_badge = f"""
                <div style="width: 100px; text-align: center; {style} color: white;">
                    <span style="display: block;">{text}</span>
                </div>
            """


    @api.depends('recibo_block')
    def _compute_recibo_state_badge(self):
        for record in self:
            style = ''
            text = ''
            if record.recibo_block == True :
                style = style_css_custom['green']
                text = 'Aceptado'
            else:
                if record.recibo_rechazo == False:
                    style = style_css_custom['gray']
                    text = 'Pendiente'  
                else:
                    style = style_css_custom['red']
                    text = 'Rechazado'           
            record.recibo_state_badge = f"""
                <div style="width: 100px; text-align: center; {style} color: white;">
                    <span style="display: block;">{text}</span>
                </div>
            """

    @api.depends('tacita_block')
    def _compute_tacita_state_badge(self):
        for record in self:
            style = ''
            text = ''
            if record.tacita_block == True :
                style = style_css_custom['green']
                text = 'Aceptado'
            else:
                if record.tacita_rechazo == False:
                    style = style_css_custom['gray']
                    text = 'Pendiente'  
                else:
                    style = style_css_custom['red']
                    text = 'Rechazado'           
            record.tacita_state_badge = f"""
                <div style="width: 100px; text-align: center; {style} color: white;">
                    <span style="display: block;">{text}</span>
                </div>
            """

    @api.depends('expresa_block')
    def _compute_expresa_state_badge(self):
        for record in self:
            style = ''
            text = ''
            if record.expresa_block == True :
                style = style_css_custom['green']
                text = 'Aceptado'
            else:
                if record.expresa_rechazo == False:
                    style = style_css_custom['gray']
                    text = 'Pendiente'  
                else:
                    style = style_css_custom['red']
                    text = 'Rechazado'            
            record.expresa_state_badge = f"""
                <div style="width: 100px; text-align: center; {style} color: white;">
                    <span style="display: block;">{text}</span>
                </div>
            """


    @api.onchange('exp_invoice_file')
    def _onchange_binary_file(self):
        if self.exp_invoice_file and self.original_filename:            
            self.exp_invoice_file = self.exp_invoice_file.decode('utf-8')

    # 1
    def set_acuse_recibo(self):

        for acuse in self.acuse_recibo_id:
            if acuse.tipo_evento_radian == self.tipo_evento_radian and acuse.unlink_bool:
                raise UserError(f'El evento {acuse.tipo_evento_radian} ya fue enviado y aceptado por la DIAN')


        # validaciones

        if not self.exp_invoice_file:
            raise UserError('No ha seleccionado ninguna factura para el Acuse recibido')
        if not self.acuse_journal_id:
            raise UserError('No ha seleccionado ningun Diaro para enviar el Acuse')

        if self.tipo_evento_radian in ['031'] and not self.tipo_de_rechazo_reclamo:
            raise UserError('Debe seleccionar el tipo de Reclamo')


        pdf_data = base64.b64decode(self.exp_invoice_file)

        # Utiliza PyMuPDF para extraer texto del PDF
        pdf_document = fitz.open(stream=pdf_data, filetype='pdf')
        pdf_text = ''

        for page_num in range(len(pdf_document)):
            page = pdf_document[page_num]
            pdf_text += page.get_text()

        # Expresión regular para buscar un hexadecimal de 64 o más caracteres
        hex_pattern = r'[0-9a-fA-F]{96}'

        # Buscar la expresión regular en el texto extraído
        cufe_cude = re.findall(hex_pattern, pdf_text)

        if not cufe_cude:
            raise UserError("EL pdf de la factura no tiene CUFE")


        acuse_data = {
            'invoice': self.id,
            'cufe_cude': cufe_cude[0],
            'company_id': self.company_id.id,
            'xml_filename': 'a.xml',
            'zipped_filename': 'b.zip',            
            'journal_id' : self.acuse_journal_id.id,
            'tipo_documento' : self.tipo_documento,
            'tipo_evento_radian' : self.tipo_evento_radian,
            'tipo_de_rechazo_reclamo':self.tipo_de_rechazo_reclamo,

        }
        self.update({'invoice_cufe':cufe_cude[0]})
        acuse_create = self.env['acuse.recibo'].create(acuse_data)


        self.write({
            'acuse_recibo_id': [(4,acuse_create.id)]
        })

        self.update({'set_acuse_recibo_ok':True})
        self.update({'set_acuse_values_ok':True})
        self.update({'send_acuse_dian_ok':False})

    # 2
    def set_acuse_values(self):
        for acuse in self.acuse_recibo_id:
            if acuse.tipo_evento_radian == self.tipo_evento_radian and acuse.unlink_bool == False:
                res = acuse.get_status()
                if res:
                    self.update({'set_acuse_recibo_ok':True})
                    self.update({'set_acuse_values_ok':False})
                    self.update({'send_acuse_dian_ok':True})
                else:
                    self.update_send_to_start()


    # 3
    def send_acuse_dian(self):
        for acuse in self.acuse_recibo_id:
            if acuse.tipo_evento_radian == self.tipo_evento_radian and acuse.unlink_bool == False:
                res = acuse.action_send_acuse()
                if res == True:
                    self.update({'set_acuse_recibo_ok':False})
                    self.update({'set_acuse_values_ok':False})
                    self.update({'send_acuse_dian_ok':False})

                    if acuse.tipo_evento_radian == '030':
                        self.update({'acuse_block':True})
                    if acuse.tipo_evento_radian == '031':
                        self.update({'reclamo_block':True})
                    if acuse.tipo_evento_radian == '032':
                        self.update({'recibo_block':True})
                    if acuse.tipo_evento_radian == '033':
                        self.update({'tacita_block':True})
                    if acuse.tipo_evento_radian == '034':
                        self.update({'expresa_block':True})


                else:
                    self.update_send_to_start()

                    if acuse.tipo_evento_radian == '030':
                        self.update({'acuse_rechazo':True})
                    if acuse.tipo_evento_radian == '031':
                        self.update({'reclamo_rechazo':True})
                    if acuse.tipo_evento_radian == '032':
                        self.update({'recibo_rechazo':True})
                    if acuse.tipo_evento_radian == '033':
                        self.update({'tacita_rechazo':True})
                    if acuse.tipo_evento_radian == '034':
                        self.update({'expresa_rechazo':True})


                    # alert_message = f"El Acuse no fue aceptado por la DIAN {res}"
                    # return {
                    #             'type': 'ir.actions.client',
                    #             'tag': 'display_notification',
                    #             'params': {
                    #                 'title': _('Warning'),
                    #                 'type': 'warning',
                    #                 'message': alert_message,
                    #                 'sticky': True,
                    #             }
                    #         }



    def update_send_to_start(self):
        self.update({'set_acuse_recibo_ok':False})
        self.update({'set_acuse_values_ok':False})
        self.update({'send_acuse_dian_ok':False})

        for acuse in self.acuse_recibo_id:
            if acuse.tipo_evento_radian == self.tipo_evento_radian and acuse.unlink_bool == False:
                self.update({'acuse_recibo_id':[(3, acuse.id)]})

        return True



    # def _get_einvoicing_taxes_acuse(self):

    #     msg1 = _("Your tax: '%s', has no e-invoicing tax group type, " +
    #              "contact with your administrator.")
    #     msg2 = _("Your withholding tax: '%s', has amount equal to zero (0), the withholding taxes " +
    #              "must have amount different to zero (0), contact with your administrator.")
    #     msg3 = _("Your tax: '%s', has negative amount or an amount equal to zero (0), the taxes " +
    #              "must have an amount greater than zero (0), contact with your administrator.")
    #     taxes = {}
    #     withholding_taxes = {}
    #     company_currency = self.company_id.currency_id

    #     for tax in self.line_ids:
    #         # _logger.info("tax.tax_line_id.amount")
    #         # _logger.info("tax.tax_line_id.amount")
    #         # _logger.info("tax.tax_line_id.amount")
    #         # _logger.info("tax.tax_line_id.amount")
    #         # _logger.info(tax.tax_line_id.amount)
    #         # _logger.info(tax.tax_line_id.tax_group_id)
    #         # _logger.info(tax.tax_line_id.tax_group_id.is_einvoicing)

    #         if tax.tax_line_id.tax_group_id.is_einvoicing:
    #             if not tax.tax_line_id.tax_group_id.tax_group_type_id:
    #                 raise UserError(msg1 % tax.name)

    #             tax_code = tax.tax_line_id.tax_group_id.tax_group_type_id.code
    #             tax_name = tax.tax_line_id.tax_group_id.tax_group_type_id.name
    #             tax_type = tax.tax_line_id.tax_group_id.tax_group_type_id.type
    #             rate = 1
    #             date = fields.Date.context_today(self)
    #             # tax_percent = '{:.2f}'.format(tax.tax_line_id.amount)
    #             tax_percent = str('{:.2f}'.format(tax.tax_line_id.amount))                
    #             if tax_type == 'withholding_tax' and tax.tax_line_id.amount == 0:
    #                 raise UserError(msg2 % tax.name)
    #             elif tax_type == 'withholding_tax' and tax.tax_line_id.amount < 0:
    #                 if tax_code not in withholding_taxes:
    #                     withholding_taxes[tax_code] = {}
    #                     withholding_taxes[tax_code]['total'] = 0
    #                     withholding_taxes[tax_code]['name'] = tax_name
    #                     withholding_taxes[tax_code]['taxes'] = {}

    #                 if float(tax_percent) < 0.0:
    #                     tax_percent = str('{:.2f}'.format(tax.tax_line_id.amount * (-1)))
    #                     # tax_percent = str(tax.tax_line_id.amount*(-1))
    #                     _logger.info('tax_percent')
    #                     _logger.info('tax_percent')
    #                     _logger.info(tax_percent)

    #                 if tax_percent not in withholding_taxes[tax_code]['taxes']:
    #                     withholding_taxes[tax_code]['taxes'][tax_percent] = {}
    #                     withholding_taxes[tax_code]['taxes'][tax_percent]['base'] = 0
    #                     withholding_taxes[tax_code]['taxes'][tax_percent]['amount'] = 0

    #                 if self.currency_id.id != company_currency.id:
    #                     currency = self.currency_id                        
    #                     rate = currency._convert(rate, company_currency, self.company_id, date)
    #                     withholding_taxes[tax_code]['total'] += (((
    #                                                                       tax.tax_base_amount / rate) * tax.tax_line_id.amount) / 100) * (
    #                                                                 -1)
    #                     withholding_taxes[tax_code]['taxes'][tax_percent]['base'] += tax.tax_base_amount / rate
    #                     withholding_taxes[tax_code]['taxes'][tax_percent]['amount'] += (((
    #                                                                                              tax.tax_base_amount / rate) * tax.tax_line_id.amount) / 100) * (
    #                                                                                        -1)
    #                 else:
    #                     withholding_taxes[tax_code]['total'] += ((
    #                                                                      tax.tax_base_amount * tax.tax_line_id.amount) / 100) * (
    #                                                                 -1)
    #                     withholding_taxes[tax_code]['taxes'][tax_percent]['base'] += tax.tax_base_amount
    #                     withholding_taxes[tax_code]['taxes'][tax_percent]['amount'] += ((
    #                                                                                             tax.tax_base_amount * tax.tax_line_id.amount) / 100) * (
    #                                                                                        -1)

    #             elif tax_type == 'withholding_tax' and tax.tax_line_id.amount > 0:

    #                 pass
    #             else:
    #                 if tax_code not in taxes:
    #                     taxes[tax_code] = {}
    #                     taxes[tax_code]['total'] = 0
    #                     taxes[tax_code]['name'] = tax_name
    #                     taxes[tax_code]['taxes'] = {}

    #                 if tax_percent not in taxes[tax_code]['taxes']:
    #                     taxes[tax_code]['taxes'][tax_percent] = {}
    #                     taxes[tax_code]['taxes'][tax_percent]['base'] = 0
    #                     taxes[tax_code]['taxes'][tax_percent]['amount'] = 0
                    
    #                 if self.currency_id.id != company_currency.id:
    #                     currency = self.currency_id
    #                     rate = currency._convert(rate, company_currency, self.company_id, date)
    #                     taxes[tax_code]['total'] += (((tax.tax_base_amount / rate) * tax.tax_line_id.amount) / 100)
    #                     taxes[tax_code]['taxes'][tax_percent]['base'] += tax.tax_base_amount / rate
    #                     taxes[tax_code]['taxes'][tax_percent]['amount'] += (
    #                             ((tax.tax_base_amount / rate) * tax.tax_line_id.amount) / 100)
    #                 else:
    #                     taxes[tax_code]['total'] += ((tax.tax_base_amount * tax.tax_line_id.amount) / 100)
    #                     taxes[tax_code]['taxes'][tax_percent]['base'] += tax.tax_base_amount
    #                     taxes[tax_code]['taxes'][tax_percent]['amount'] += (
    #                             (tax.tax_base_amount * tax.tax_line_id.amount) / 100)

    #     return {'TaxesTotal': taxes, 'WithholdingTaxesTotal': withholding_taxes}