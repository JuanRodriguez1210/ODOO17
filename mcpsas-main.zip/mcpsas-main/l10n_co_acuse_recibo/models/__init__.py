# -*- coding: utf-8 -*-

from . import acuse_recibo
from . import l10n_latam_identification_type
from . import account_move