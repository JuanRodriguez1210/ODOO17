# -*- coding: utf-8 -*-
{
    'name': "acuse_recibo nbt",

    'summary': """        
        Agrega campos para manejo de acuse de recibo.""",

    'description': """
        Agrega campos para manejo de acuse de recibo
    """,

    "author" : "NIMBUTECH S.A.S",
    "email": 'desarrollo.odoo@nimbutech.com',
    "website":'https://www.nimbutech.com/',
    'version': '17.0',
    'license': 'OPL-1',
    'category': 'Data extend',

    # any module necessary for this one to work correctly
    'depends': ['base','account','l10n_latam_base','l10n_co_dian_data'],

    # always loaded
    'data': [        
        'views/acuse_recibo.xml',        
        'views/l10n_latam_identification_type.xml',
        'views/account_move.xml',
        'security/res_groups.xml',
        'security/ir.model.access.csv',
        
    ],
}
