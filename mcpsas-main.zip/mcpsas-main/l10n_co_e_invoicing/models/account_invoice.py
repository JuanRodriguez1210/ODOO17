# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S
from datetime import datetime, timedelta
from pytz import timezone
import zipfile
from io import BytesIO

import datetime as dt
from odoo import api, models, fields, _, api
from odoo.exceptions import UserError, ValidationError
from odoo.tools.misc import formatLang, format_date, get_lang
from base64 import b64encode, b64decode
import base64
import re
import uuid
from . import global_functions

import logging
_logger = logging.getLogger(__name__)


class AccountInvoice(models.Model):
	_inherit = "account.move"

	@api.model
	def _default_payment_mean(self):
		id_model = self.env['account.payment.mean'].search(
		    [], order='id asc', limit=1)
		return id_model

	payment_mean_id = fields.Many2one(
		comodel_name='account.payment.mean',
		string='Payment Method',
		default=_default_payment_mean)

	approve_token = fields.Char(
		string='Access Token for approve',
		copy=False
	)

	invoice_rating = fields.Selection(
		selection=[
			('not_rating', 'No Calificada'),
			('approve', 'Aprobada'),
			('refuse', 'Rechazada'),
			('auto_approve', 'Aprobada por Vencimiento')],
		string='Aprobación de Factura',
		default='',
		copy=False
	)

	refuse_text = fields.Text(
        string='Motivo del rechazo',
        copy=False
    )

	def _get_warn_pfx(self):
		"""
		Calcula si se debe mostrar una advertencia (`warn_pfx`) y el número de días restantes (`days`).

		La advertencia se muestra si el diario está marcado como `is_einvoicing` y ya sea que la fecha de vencimiento esté dentro de los días restantes o no se haya establecido una fecha de vencimiento.
		El número de días restantes se calcula como la diferencia entre la fecha de vencimiento y la fecha de hoy.
		Los resultados se almacenan en los campos `warn_pfx` y `pfx_available_days` del registro actual.

		Args:
			self: El registro actual.

		Returns:
			None. La función actualiza los campos `warn_pfx` y `pfx_available_days` del registro actual.
		"""
		warn_pfx = False
		days = 0
		if self.journal_id.is_einvoicing:
			remaining_days = self.company_id.remaining_days_pfx
			date_due = self.company_id.date_due_pfx
			today = datetime.strptime(
			    str(datetime.now(timezone(self.env.user.tz)).date()), '%Y-%m-%d')
			if date_due:
				date_to = datetime.strptime(str(date_due), '%Y-%m-%d')
				days = (date_to - today).days
				if days < remaining_days:
					warn_pfx = True
			else:
				warn_pfx = True

		self.warn_pfx = warn_pfx
		self.pfx_available_days = days

	dian_document_lines = fields.One2many('account.invoice.dian.document', 'invoice_id', string='Dian Document Lines')
	operation_type = fields.Selection([('09', 'AIU'),
									   ('10', 'Standard *'),
									   ('11', 'Mandatos'),
									   ('20', 'Credit note that references an e-invoice'),
									   ('22', 'Credit note without reference to invoices *'),
									   ('30', 'Debit note that references an e-invoice'),
									   ('32', 'Debit note without reference to invoices *')], string='Operation Type', default='10')
	invoice_type_code = fields.Selection([('01', 'Factura de Venta'),
		 								  ('02', 'Factura de Venta Exportación'),
										  ('03', 'Factura por Contingencia Facturador'),
										  ('04', 'Factura por Contingencia DIAN')], string='Invoice Type', default='01')
	send_invoice_to_dian = fields.Selection([('0', 'Immediately'),
		 									 ('1', 'After 1 Day'),
											 ('2', 'After 2 Days')], string='Send Invoice to DIAN?', default='0')
	trm = fields.Float()
	is_invoice_out_odoo = fields.Boolean('Creada fuera de odoo?')
	id_invoice_refound = fields.Char('Factura')
	uuid_invoice = fields.Char('Cufe')
	issue_date_invoice = fields.Date('Fecha')
	customizationid_invoice = fields.Integer(string="Tipo de operación Factura", default=10)
	aiu = fields.Char(string='AIU')

	credit_note_ids = fields.One2many('account.move', 'reversed_entry_id', string="Notas crédito")

	credit_note_count = fields.Integer('Number of Credit Notes', compute='_compute_credit_count')
	mandante_id = fields.Many2one('res.partner', string="Mandante")

	warn_pfx = fields.Boolean(string="Certificado DIAN por vencer", compute="_get_warn_pfx", store=False)
	pfx_available_days = fields.Integer(string="Días disponibles", compute="_get_warn_pfx", store=False)
	status_dian_document = fields.Selection([('00', 'Procesado Correctamente'),
                                             ('66', 'NSU no encontrado'),
											 ('90', 'TrackId no encontrado'),
											 ('99', 'Validaciones contienen errores en campos mandatorios'),
											 ('111', 'Tiene más de un documento DIAN'),
											 ('other', 'Other')], string='Estado doc. DIAN', compute="_get_status_doc_dian", default=False, tracking=True)
	orden_compra = fields.Char(string='Orden de compra')
	cufe_cude = fields.Char(string='CUFE/CUDE', tracking=True)

	start_invoice_period = fields.Date(
	    string='Inicio periodo de facturación', store=True)
	end_invoice_period = fields.Date(
	    string='Fin periodo de facturación', store=True)

	@api.depends('trm', 'amount_total', 'currency_id')
	def _compute_total_en_pesos(self):
		for record in self:
			if record.currency_id and record.currency_id.name == 'USD' and record.trm:
				record.total_en_pesos = record.amount_total * record.trm
			else:
				record.total_en_pesos = record.amount_total

	@api.depends('invoice_line_ids', 'invoice_line_ids.product_id')
	def _compute_total_ingreso_propio(self):
		for record in self:
			total = 0.0
			for line in record.invoice_line_ids:
				if line.product_id and line.product_id.tipo_ingreso == 'ip':
					total += line.price_subtotal
			record.total_ingreso_propio = total

	@api.depends('invoice_line_ids', 'invoice_line_ids.product_id')
	def _compute_total_ingreso_tercero(self):
		for record in self:
			total = 0.0
			for line in record.invoice_line_ids:
				if line.product_id and line.product_id.tipo_ingreso == 'it':
					total += line.price_subtotal
			record.total_ingreso_tercero = total

	@api.depends('dian_document_lines')
	def _get_status_doc_dian(self):
		for record in self:
			if record.journal_id.is_einvoicing and record.dian_document_lines:
				if len(record.dian_document_lines) > 1:
					record.status_dian_document = '111'
				elif len(record.dian_document_lines) == 1:
					record.status_dian_document = record.dian_document_lines.get_status_zip_status_code
				else:
					record.status_dian_document = False
			else:
				record.status_dian_document = False


	@api.depends('credit_note_ids')
	def _compute_credit_count(self):
		credit_data = self.env['account.move'].read_group([('reversed_entry_id', 'in', self.ids)],
															['reversed_entry_id'], ['reversed_entry_id'])
		data_map = {datum['reversed_entry_id'][0]: datum['reversed_entry_id_count'] for datum in credit_data}
		for inv in self:
			inv.credit_note_count = data_map.get(inv.id, 0.0)

	def tacit_acceptation(self):
		invoice = self.search([('invoice_rating', '=', 'not_rating'), ('move_type', 'in', ('out_invoice', 'in_invoice'))], order='id asc', limit=50)
		for record in invoice:
			if record.invoice_rating == 'not_rating' and record.dian_document_lines:
				cufe_cude_cuds = self.env['account.invoice.dian.document'].search([('invoice_id', '=', record.id)], order='invoice_id desc', limit=1)
				hora_comparar = cufe_cude_cuds.create_date + dt.timedelta(hours=72)
				hora = hora_comparar - dt.datetime.now()
				horas = int(hora.total_seconds())

				if horas <= 0 and cufe_cude_cuds.get_status_zip_status_code == '00':
					dian_obj = cufe_cude_cuds
					accepted_xml_without_signature = global_functions.get_template_xml(dian_obj._get_accepted_values(), 'AceptacionTacita')
					accepted_xml_with_signature = global_functions.get_xml_with_signature(accepted_xml_without_signature, record.company_id.signature_policy_url, record.company_id.signature_policy_description, record.company_id.certificate_file, record.company_id.certificate_password)
					dian_obj.write({'exp_accepted_file': b64encode(dian_obj._get_acp_zipped_file(accepted_xml_with_signature)).decode("utf-8", "ignore")})
					dian_obj.action_sent_accepted_file(dian_obj.exp_accepted_file)
					record.invoice_rating = 'auto_approve'
					dian_obj.bs_acceptation()

	def action_view_credit_notes(self):
		self.ensure_one()
		return {
			'type': 'ir.actions.act_window',
			'name': _('Notas Crédito'),
			'res_model': 'account.move',
			'view_mode': 'tree,form',
			'domain': [('reversed_entry_id', '=', self.id)],
		}

	def _post(self, soft=True):
		for record in self:
			if record.state != 'draft':
				raise ValidationError(_('Esta factura [%s] no está en borrador, por lo tanto, no se puede publicar. \n' \
										'Por favor, recargue la página para refrescar el estado de esta factura.') % record.id)

		res = super(AccountInvoice, self)._post()

		for record in self:
			if record.company_id.einvoicing_enabled and record.journal_id.acknowledgement_receipt and record.move_type in ("in_invoice", "in_refund"):
				dian_document_obj = self.env['account.invoice.dian.document']
				dian_document = dian_document_obj.create({
					'invoice_id': record.id,
					'company_id': record.company_id.id,
					'type_account': 'support_document'
				})
				dian_document.accuse_recibo()

			if record.company_id.einvoicing_enabled and record.journal_id.is_einvoicing:
				if len(self) > 1:
					raise ValidationError(_('No está permitido publicar varias facturas electrónicas a la vez.'))
				if record._get_warn_pfx_state():
					raise ValidationError(_('Factura electrónica bloqueada. \n\n El Certificado .pfx de la compañia %s está vencido.') % record.company_id.name)

				if record.move_type in ("out_invoice", "out_refund"):
					company_currency = record.company_id.currency_id
					self.approve_token = self.approve_token if self.approve_token else str(uuid.uuid4())
					self.invoice_rating = 'not_rating'
					rate = 1
					# date = self._get_currency_rate_date() or fields.Date.context_today(self)
					date = fields.Date.context_today(self)
					if record.currency_id.id != company_currency.id:
						currency = record.currency_id
						rate = currency._convert(rate, company_currency,
						                         record.company_id, record.invoice_date)
						record.trm = rate

					if record.move_type == 'out_invoice' and record.refund_type == 'debit':
						type_account = 'debit'
					elif record.move_type == 'out_refund' and record.refund_type != 'debit':
						type_account = 'credit'
					else:
						type_account = 'invoice'

					dian_document_obj = self.env['account.invoice.dian.document']
					dian_document = False
					dian_document = dian_document_obj.create({
						'invoice_id': record.id,
						'company_id': record.company_id.id,
						'type_account': type_account
						})
					# Se generan el xml y el zip de la factura
					dian_document.action_set_files()

					# Si la factura está configurada para ser enviada inmediatamente, se envía
					if record.send_invoice_to_dian == '0':
						# Si es una factura de venta, factura de venta exportación o factura por contingencia facturador, se envía el zip
						if record.invoice_type_code in ('01', '02', '03'):
							# Se envia el zip a la DIAN
							dian_document.action_sent_zipped_file()
						elif record.invoice_type_code == '04':
							# Si es una factura por contingencia DIAN, se envia el correo al cliente con el pdf y el xml en zip
							dian_document.action_send_mail()

		return res

	def _get_warn_pfx_state(self):
		self.ensure_one()
		warn_pfx = False
		date_due = self.company_id.date_due_pfx
		today = datetime.strptime(str(fields.Date.today(self)), '%Y-%m-%d')
		if date_due:
			date_to = datetime.strptime(str(date_due), '%Y-%m-%d')
			days = (date_to - today).days
			if days <= 0:
				warn_pfx = True
		return warn_pfx

	def _get_pdf_file(self):
		#pdf = self.env['ir.actions.report'].sudo()._run_wkhtmltopdf([self.invoice_id.id], template.report_name)
		try:
			msg ='217'
			template = self.env['ir.actions.report'].browse(self.company_id.report_template.id)
			#pdf = self.env.ref('account.move').render_qweb_pdf([self.invoice_id.id])[0]
			if template:
				msg = '221'
				pdf = template._render_qweb_pdf(template.id,self.id)
			else:
				pdf = self.env.ref('account.account_invoices')._render_qweb_pdf(self.invoice_id.id)
				msg = '225'
			pdf = pdf[0]
			msg = '227'
			pdf_name = re.sub(r'\W+', '', self.invoice_id.name) + '.pdf'
			msg = '229'

			#pdf = self.env['ir.actions.report'].sudo()._run_wkhtmltopdf([self.invoice_id.id], template.report_name)
		except Exception as e:
			_logger.error("Error cargando pdf : %s , en la linea %s", e, msg)
		return pdf

	def action_invoice_sent(self):
		""" Open a window to compose an email, with the edi invoice template
			message loaded by default
		"""
		self.ensure_one()
		template = self.env.ref('l10n_co_e_invoicing.email_template_for_einvoice')
		buff = BytesIO()
		zip_file = zipfile.ZipFile(buff, mode='w')
		# template = self.env.ref('account.email_template_edi_invoice', raise_if_not_found=False)

		xml_attachment_file = False
		name_xlm = False
		for item in self.dian_document_lines:
			name_xlm = item.xml_filename.replace('.xml', '')
		if not name_xlm:
			name_xlm = self.name
		if self.dian_document_lines.filtered(lambda x: x.ar_xml_file and x.xml_file):
			xml_without_signature = global_functions.get_template_xml(
				self.dian_document_lines._get_attachment_values(),
				'attachment')

			xml_attachment_file = self.env['ir.attachment'].create({
				'name': name_xlm + '.xml',
				'type': 'binary',
				'datas': b64encode(xml_without_signature.encode()).decode("utf-8", "ignore")})

		if xml_attachment_file:
			zip_content = BytesIO()
			zip_content.write(
				base64.b64decode(base64.b64encode(xml_without_signature.encode()).decode("utf-8", "ignore")))
			zip_file.writestr(name_xlm + '.xml', zip_content.getvalue())

		pdf_attachment = self.env['ir.attachment'].create({
			'name': name_xlm + '.pdf',
			'type': 'binary',
			'datas': base64.b64decode(base64.b64encode(self._get_pdf_file()))})
		zip_content = BytesIO()
		zip_content.write(base64.b64decode(base64.b64encode(self._get_pdf_file())))
		zip_file.writestr(name_xlm + '.pdf', zip_content.getvalue())

		zip_file.close()
		zipped_file = base64.b64encode(buff.getvalue())
		buff.close()

		attachment = self.env['ir.attachment'].create({
			'name': name_xlm + '.zip',
			'type': 'binary',
			'datas': zipped_file,
		})

		attach_ids = [attachment.id]

		template.attachment_ids = [(6, 0, attach_ids)]

		lang = False
		if template:
			lang = template._render_lang(self.ids)[self.id]
		if not lang:
			lang = get_lang(self.env).code

		compose_form = self.env.ref('account.account_invoice_send_wizard_form', raise_if_not_found=False)
		ctx = dict(
			default_model='account.move',
			default_res_id=self.id,
			default_use_template=bool(template),
			default_template_id=template and template.id or False,
			default_composition_mode='comment',
			mark_invoice_as_sent=True,
			custom_layout="mail.mail_notification_paynow",
			model_description=self.with_context(lang=lang).type_name,
			force_email=True
		)

		return {
			'name': _('Send Invoice'),
			'type': 'ir.actions.act_window',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'account.invoice.send',
			'views': [(compose_form.id, 'form')],
			'view_id': compose_form.id,
			'target': 'new',
			'context': ctx,
		}

	# def invoice_validate(self):

	# 	res = super(AccountInvoice, self).invoice_validate()

	# 	if self.company_id.einvoicing_enabled:
	# 		if self.type != "in_invoice":
	# 			dian_document_obj = self.env['account.invoice.dian.document']
	# 			dian_document = dian_document_obj.create({
	# 				'invoice_id': self.id,
	# 				'company_id': self.company_id.id})
	# 			dian_document.set_files()
	# 			dian_document.sent_zipped_file()
	# 			dian_document.GetStatusZip()

	# 	return res

	def _get_payment_exchange_rate(self):
		# Obtener moneda COP
		cop_currency = self.env['res.currency'].search(
		    [('name', '=', 'COP')], limit=1)
		rate = 1
		source_rate = 1
		# Si la moneda de la factura es diferente a COP
		if cop_currency and cop_currency.id != self.currency_id.id:
			if self.move_type == 'out_refund':
				# Si es una nota crédito, se obtiene la tasa de cambio de la factura original
				rate = self.reversed_entry_id.trm
			else:
				# Si es una factura de venta, se obtiene la tasa de cambio de la fecha de facturación
				# A cuanto equivale 1 unidad de la moneda de la factura en COP
				rate = self.currency_id._convert(
				    rate, cop_currency, self.company_id, self.invoice_date)

			# A cuanto equivale 1 unidad de la moneda de la factura en la moneda de la factura
			source_rate = self.currency_id._convert(
			    1, cop_currency, self.company_id, self.invoice_date)

		return {
			'SourceCurrencyCode': 'COP',  # FAR02 - Divisa base del documento siempre es COP
			# FAR03 - Valor de la moneda en COP.
			'SourceCurrencyBaseRate': '{:.2f}'.format(source_rate),
			# FAR04 - Divisa a la cual se hace la conversión.
			'TargetCurrencyCode': self.currency_id.name,
			# FAR05 - Base monetaria para la conversión. Debe ser 1.00
			'PaymentExchangeRate': '{:.2f}'.format(1),
			# FAR06 - Valor de la tasa de cambio entre las divisas
			'CalculationRate': '{:.2f}'.format(rate),
			'Date': self.invoice_date  # FAR07
		}

	def button_cancel(self):
		res = super(AccountInvoice, self).button_cancel()

		for dian_document in self.dian_document_lines:
			if dian_document.state == 'done':
				raise UserError(_('No puede cancelar una factura procesada en la DIAN'))

		return res

	def button_draft(self):
		res = super(AccountInvoice, self).button_draft()

		for dian_document in self.dian_document_lines:
			if dian_document.state == 'done':
				raise UserError(_('No puede cambiar a borrador una factura procesada en la DIAN'))

		return res

	def _get_billing_reference(self):
		billing_reference = {}
		msg1 = ''
		msg2 = _('La nota %s no tiene referencia de facturación \n\n') % 'crédito' if self.refund_type == 'credit' else 'débito' if self.refund_type == 'debit' else ''
		#for origin_invoice in self.refund_invoice_id:
		origin_invoice_id = self.reversed_entry_id if self.refund_type == 'credit' else self.debit_origin_id if self.refund_type == 'debit' else False
		for origin_invoice in origin_invoice_id:
			if origin_invoice.state in ('open', 'paid', 'posted'):
				for dian_document in origin_invoice.dian_document_lines:
					if dian_document.state == 'done':
						billing_reference['ID'] = origin_invoice.name
						billing_reference['UUID'] = dian_document.cufe_cude
						billing_reference['IssueDate'] = origin_invoice.invoice_date
						billing_reference['CustomizationID'] = origin_invoice.operation_type
					else:
						msg1 = _('El documento DIAN de la factura %s no está procesado correctamente. Por favor, validar su estado en la DIAN.') % origin_invoice.name

		if not billing_reference:
			raise UserError(msg2 + msg1)
		else:
			return billing_reference

	def _get_active_dian_resolution(self):
		msg = _("You do not have an active dian resolution, "
				"contact with your administrator.")
		resolution_number = False
		date_from = False
		date_to = False
		number_from = False
		number_to = False
		technical_key = False

		for date_range_id in self.journal_id.sequence_id.date_range_ids:
			if date_range_id.active_resolution:
				resolution_number = date_range_id.resolution_number
				date_from = date_range_id.date_from
				date_to = date_range_id.date_to
				number_from = date_range_id.number_from
				number_to = date_range_id.number_to
				technical_key = date_range_id.technical_key
				break

		if not resolution_number:
			raise UserError(msg)

		return {
			'prefix': self.journal_id.sequence_id.prefix or '',
			'resolution_number': resolution_number,
			'date_from': date_from,
			'date_to': date_to,
			'number_from': number_from,
			'number_to': number_to,
			'technical_key': technical_key}

	def _get_einvoicing_taxes(self, to_currency=False):
		msg1 = _("Your tax: '%s', has no e-invoicing tax group type, " +
				 "contact with your administrator.")
		msg2 = _("Your withholding tax: '%s', has amount equal to zero (0), the withholding taxes " +
				 "must have amount different to zero (0), contact with your administrator.")
		msg3 = _("Your tax: '%s', has negative amount or an amount equal to zero (0), the taxes " +
				 "must have an amount greater than zero (0), contact with your administrator.")
		taxes = {}
		withholding_taxes = {}
		company_currency = self.company_id.currency_id

		# Recorrer las lineas de la factura
		for line in self.line_ids:
			# Si la facturacion electronica esta activa y la linea tiene impuestos
			if line.tax_line_id.tax_group_id.is_einvoicing:
				if not line.tax_line_id.tax_group_id.tax_group_type_id:
					raise UserError(msg1 % line.name)

				tax_code = line.tax_line_id.tax_group_id.tax_group_type_id.code
				tax_name = line.tax_line_id.tax_group_id.tax_group_type_id.name
				tax_type = line.tax_line_id.tax_group_id.tax_group_type_id.type

				# Obtener el porcentaje del impuesto con dos decimales
				tax_percent = str('{:.2f}'.format(line.tax_line_id.amount))

				# Si las retenciones son 0, se lanza un error
				if tax_type == 'withholding_tax' and line.tax_line_id.amount == 0:
					raise UserError(msg2 % line.name)
				# Si los impuestos son negativos se lanza un error
				elif tax_type == 'tax' and line.tax_line_id.amount < 0:
					raise UserError(msg3 % line.name)
				# elif tax_type == 'tax' and tax.tax_line_id.amount == 0:
				# 	pass
				# Si las retenciones son negativas
				elif tax_type == 'withholding_tax' and line.tax_line_id.amount < 0:
					# En caso de que el codigo del grupo de la retencion no exista en el diccionario de retenciones inicarlo en 0
					if tax_code not in withholding_taxes:
						withholding_taxes[tax_code] = {}
						withholding_taxes[tax_code]['total'] = 0
						withholding_taxes[tax_code]['name'] = tax_name
						withholding_taxes[tax_code]['taxes'] = {}

					# Poner el porcentaje en numero positivo
					if float(tax_percent) < 0.0:
						tax_percent = str('{:.2f}'.format(line.tax_line_id.amount * (-1)))
						# tax_percent = str(tax.tax_line_id.amount*(-1))

					# Si el porcentaje no existe en el grupo de la retenciones, inicializarlo en 0
					if tax_percent not in withholding_taxes[tax_code]['taxes']:
						withholding_taxes[tax_code]['taxes'][tax_percent] = {}
						withholding_taxes[tax_code]['taxes'][tax_percent]['base'] = 0
						withholding_taxes[tax_code]['taxes'][tax_percent]['amount'] = 0

					# Obtener el valor de la retencion y sumarlo al total del grupo de retenciones
					#  line.tax_base_amount Ya viene con la moneda de la compañia
					base = self.company_id.currency_id._convert(
					    line.tax_base_amount, self.currency_id, self.company_id, self.invoice_date)

					amount = (base * (line.tax_line_id.amount / 100)) * (-1)
					withholding_taxes[tax_code]['taxes'][tax_percent]['base'] += base
					withholding_taxes[tax_code]['taxes'][tax_percent]['amount'] += amount
					withholding_taxes[tax_code]['total'] += amount

				# Si las retenciones son positivas
				elif tax_type == 'withholding_tax' and line.tax_line_id.amount > 0:
					# TODO 3.0 Las retenciones se recomienda no enviarlas a la DIAN
					# Solo las positivas que indicarian una autoretencion, Si la DIAN
					# pide que se envien las retenciones, seria quitar o comentar este if

					pass
				else:
					if tax_code not in taxes:
						taxes[tax_code] = {}
						taxes[tax_code]['total'] = 0
						taxes[tax_code]['name'] = tax_name
						taxes[tax_code]['taxes'] = {}

					if tax_percent not in taxes[tax_code]['taxes']:
						taxes[tax_code]['taxes'][tax_percent] = {}
						taxes[tax_code]['taxes'][tax_percent]['base'] = 0
						taxes[tax_code]['taxes'][tax_percent]['amount'] = 0

					base = self.company_id.currency_id._convert(
					    line.tax_base_amount, self.currency_id, self.company_id, self.invoice_date)
					taxes[tax_code]['total'] += base * (line.tax_line_id.amount / 100)
					taxes[tax_code]['taxes'][tax_percent]['base'] += base
					taxes[tax_code]['taxes'][tax_percent]['amount'] += base * \
					    (line.tax_line_id.amount / 100)

		conversion_currency = False

		if to_currency:
			conversion_currency = to_currency
		elif self.currency_id.id != self.company_id.currency_id.id:
			conversion_currency = self.company_id.currency_id

		if conversion_currency:
			for tax_code in taxes:
				taxes[tax_code]['total'] = self.currency_id._convert(float(
				    taxes[tax_code]['total']), conversion_currency, self.company_id, self.invoice_date)
				for tax_percent in taxes[tax_code]['taxes']:
					taxes[tax_code]['taxes'][tax_percent]['base'] = self.currency_id._convert(float(
					    taxes[tax_code]['taxes'][tax_percent]['base']), conversion_currency, self.company_id, self.invoice_date)
					taxes[tax_code]['taxes'][tax_percent]['amount'] = self.currency_id._convert(float(
					    taxes[tax_code]['taxes'][tax_percent]['amount']), conversion_currency, self.company_id, self.invoice_date)

			for tax_code in withholding_taxes:
				withholding_taxes[tax_code]['total'] = self.currency_id._convert(
				    withholding_taxes[tax_code]['total'], conversion_currency, self.company_id, self.invoice_date)
				for tax_percent in withholding_taxes[tax_code]['taxes']:
					withholding_taxes[tax_code]['taxes'][tax_percent]['base'] = self.currency_id._convert(
					    withholding_taxes[tax_code]['taxes'][tax_percent]['base'], conversion_currency, self.company_id, self.invoice_date)
					withholding_taxes[tax_code]['taxes'][tax_percent]['amount'] = self.currency_id._convert(
					    withholding_taxes[tax_code]['taxes'][tax_percent]['amount'], conversion_currency, self.company_id, self.invoice_date)

		return {'TaxesTotal': taxes, 'WithholdingTaxesTotal': withholding_taxes}

	def _get_tax_representative_party_values(self):
		if self.type in ('out_invoice', 'out_refund'):
			supplier = self.company_id.partner_id
		else:
			supplier = self.partner_id

		return {
			'IDschemeID': supplier.check_digit,
			'IDschemeName': supplier.document_type_id.code,
			'ID': supplier.identification_document}

	def _get_invoice_lines(self, to_currency=False):
		invoice_lines = {}
		count = 1

		for invoice_line in self.invoice_line_ids.filtered(lambda x:  x.display_type  in ['product']):
			if not invoice_line.product_uom_id.product_uom_code_id:
				raise UserError(_("Your Unit of Measure: '%s', has no Unit of Measure Code, contact with your administrator.") %
				                invoice_line.product_uom_id.name)
			if not invoice_line.product_id or not invoice_line.product_id.default_code:
				raise UserError(_("The invoice line %s has no reference") %
				                invoice_line.name)
			if invoice_line.price_unit == 0 or invoice_line.quantity == 0:
				raise ValidationError(
				    _('Electronic invoicing is not allowed for product lines with price or quantity of 0.'))

			price_subtotal = self.currency_id._convert(invoice_line.price_subtotal, to_currency, self.company_id, self.invoice_date)
			margin_percentage = invoice_line.product_id.currency_id._convert(invoice_line.product_id.margin_percentage, to_currency, self.company_id, self.invoice_date)
			standard_price = invoice_line.product_id.currency_id._convert(invoice_line.product_id.with_company(self.company_id).standard_price, to_currency, self.company_id, self.invoice_date)
			discount_factor = invoice_line.discount # Porcentaje de descuento
			price_unit = invoice_line.currency_id._convert(invoice_line.price_unit, to_currency, self.company_id, self.invoice_date)

			reference_price = margin_percentage or standard_price

			if price_subtotal <= 0 and reference_price <= 0:
				raise UserError(_("Your product: '%s', has no reference price, contact with your administrator.") %
				                invoice_line.product_id.default_code)

			product_scheme_id = invoice_line.product_id.product_scheme_id or self.env['product.scheme'].search([
			                                                                                                   ('code', '=', '999')])
			invoice_line_data = {
                'Note': 'Contrato de servicios AIU por concepto de: ' + self.aiu if self.operation_type == '09' else '',
                'unitCode': invoice_line.product_uom_id.product_uom_code_id.code,
                'Quantity': '{:.2f}'.format(invoice_line.quantity), # Cantidad de unidades
                'PriceAmount': '{:.2f}'.format(reference_price), # Precio de venta unitario
                'LineExtensionAmount': '{:.2f}'.format(price_subtotal), # Precio total de la línea
                'PricingReference': '{:.2f}'.format(reference_price or 0.0), # Precio de referencia
                'MultiplierFactorNumeric': '{:.2f}'.format(discount_factor), # Descuento %
                'AllowanceChargeAmount': '{:.2f}'.format((price_subtotal * discount_factor) / 100 if price_subtotal != 0 and discount_factor != 0 else 0), # Descuento aplicado
                'AllowanceChargeBaseAmount': '{:.2f}'.format(price_unit * invoice_line.quantity if price_unit != 0 and invoice_line.quantity != 0 else 0), # Precio base al que se le aplicó el descuento
                'TaxesTotal': {},
                'WithholdingTaxesTotal': {},
                'SellersItemIdentification': invoice_line.product_id.default_code,
                'StandardItemIdentification': invoice_line.product_id.product_scheme_code or '',
                'StandardschemeID': product_scheme_id.code or '',
                'StandardschemeName': product_scheme_id.name or '',
                'StandardschemeAgencyID': product_scheme_id.scheme_agency_id or '',
                'BrandName': invoice_line.product_id.brand_name or '',
                'ModelName': invoice_line.product_id.model_name or '',
                'ItemDescription': str(invoice_line.name) if invoice_line.name != invoice_line.product_id.display_name else invoice_line.product_id.name or '',
                'InformationContentProviderParty': invoice_line._get_information_content_provider_party_values(),
                'PriceAmount': '{:.2f}'.format(price_unit)
            }

			invoice_line_data.update(
			    self._get_invoice_line_taxes(invoice_line, to_currency))
			if '01' not in invoice_line_data['TaxesTotal']:
				base_iva = price_subtotal
				invoice_line_data['TaxesTotal']['01'] = {
                    'total': 0,
                    'name': 'IVA',
                    'taxes': {
                        '0.00': {
                            'base': round(base_iva, 2),
                            'amount': 0
                        }
                    }
                }

			invoice_lines[count] = invoice_line_data
			count += 1

		return invoice_lines

	def _get_invoice_line_taxes(self, invoice_line, to_currency):
		taxes_data = {'TaxesTotal': {}, 'WithholdingTaxesTotal': {}}
		for tax in invoice_line.tax_ids:
			tax_ids = tax.children_tax_ids if tax.amount_type == 'group' else tax

			for tax_id in tax_ids:
				if tax_id.tax_group_id.is_einvoicing:
					if not tax_id.tax_group_id.tax_group_type_id:
						raise UserError(_("Your tax: '%s', has no e-invoicing tax group type, contact with your administrator.") % tax.name)

					tax_type = tax_id.tax_group_id.tax_group_type_id.type
					if tax_type == 'withholding_tax' and tax_id.amount == 0:
						raise UserError(_("Your withholding tax: '%s', has amount equal to zero (0), the withholding taxes must have amount different to zero (0), contact with your administrator.") % tax_id.name)
					elif tax_type == 'tax' and tax_id.amount < 0:
						raise UserError(_("Your tax: '%s', has negative amount or an amount equal to zero (0), the taxes must have an amount greater than zero (0), contact with your administrator.") % tax_id.name)
					elif tax_type == 'withholding_tax' and tax_id.amount < 0:
						taxes_data['WithholdingTaxesTotal'] = invoice_line._get_invoice_lines_taxes(tax_id, abs(tax_id.amount), taxes_data['WithholdingTaxesTotal'], to_currency=to_currency)
					elif tax_type == 'tax' and tax_id.amount > 0:
						taxes_data['TaxesTotal'] = invoice_line._get_invoice_lines_taxes(tax_id, tax_id.amount, taxes_data['TaxesTotal'], to_currency=to_currency)

		return taxes_data