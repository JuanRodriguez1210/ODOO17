# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S

from odoo import models, fields, _, api
from odoo.exceptions import UserError, ValidationError


class AccountInvoiceLine(models.Model):
    _inherit = "account.move.line"

    valor_en_pesos = fields.Float(
        compute='_compute_valor_en_pesos', string='Valor en Pesos', store=True)

    @api.depends('move_id.trm', 'price_subtotal', 'move_id.currency_id')
    def _compute_valor_en_pesos(self):
        for line in self:
            if line.move_id.currency_id and line.move_id.currency_id.name == 'USD' and line.move_id.trm:
                line.valor_en_pesos = line.price_subtotal * line.move_id.trm
            else:
                line.valor_en_pesos = line.price_subtotal

    def _get_invoice_lines_taxes(self, tax, tax_amount, invoice_line_taxes_total, to_currency=False):
        tax_code = tax.tax_group_id.tax_group_type_id.code
        tax_name = tax.tax_group_id.tax_group_type_id.name
        # tax_percent = '{:.2f}'.format(tax_amount)
        tax_percent = str('{:.2f}'.format(tax_amount))

        if tax_code not in invoice_line_taxes_total:
            invoice_line_taxes_total[tax_code] = {}
            invoice_line_taxes_total[tax_code]['total'] = 0
            invoice_line_taxes_total[tax_code]['name'] = tax_name
            invoice_line_taxes_total[tax_code]['taxes'] = {}

        if tax_percent not in invoice_line_taxes_total[tax_code]['taxes']:
            invoice_line_taxes_total[tax_code]['taxes'][tax_percent] = {}
            invoice_line_taxes_total[tax_code]['taxes'][tax_percent]['base'] = 0
            invoice_line_taxes_total[tax_code]['taxes'][tax_percent]['amount'] = 0

        # Primero asignar el valor base y el valor del impuesto antes de sumarlo al total,
        # para tenerlo redondeado y no tener problemas de precision decimal con respecto al valor sumado de la DIAN

        base = self.currency_id._convert(self.price_subtotal, to_currency, self.company_id, self.move_id.invoice_date)
        amount = base * tax_amount / 100

        invoice_line_taxes_total[tax_code]['taxes'][tax_percent].update({
            'base': round(base, 2),
            'amount': round(amount, 2)
        })

        invoice_line_taxes_total[tax_code]['total'] += amount

        return invoice_line_taxes_total

    def _get_information_content_provider_party_values(self):
        return {
            'IDschemeID': False,
            'IDschemeName': False,
            'ID': False}
