# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S


import sys
import importlib
importlib.reload(sys)
import base64
import re
import zipfile

#sys.setdefaultencoding('utf8')
#from StringIO import StringIO
from io import StringIO ## for Python 3
from datetime import datetime, timedelta
from base64 import b64encode, b64decode
from zipfile import ZipFile
from . import global_functions
from pytz import timezone
from requests import post, exceptions
from lxml import etree

from odoo import models, fields, _, api
from odoo.exceptions import ValidationError, UserError
from odoo.http import request

from io import StringIO ## for Python 3
from io import BytesIO

import logging
_logger = logging.getLogger(__name__)

import ssl

ssl._create_default_https_context = ssl._create_unverified_context

DIAN = {
    'wsdl-hab': 'https://vpfe-hab.dian.gov.co/WcfDianCustomerServices.svc?wsdl',
    'wsdl': 'https://vpfe.dian.gov.co/WcfDianCustomerServices.svc?wsdl',
    'catalogo-hab': 'https://catalogo-vpfe-hab.dian.gov.co/Document/FindDocument?documentKey={}&partitionKey={}&emissionDate={}',
    'catalogo': 'https://catalogo-vpfe.dian.gov.co/Document/FindDocument?documentKey={}&partitionKey={}&emissionDate={}'
}

class AccountInvoiceDianDocument(models.Model):
    _name = "account.invoice.dian.document"
    _inherit = ['mail.thread']

    state = fields.Selection([('draft', 'Draft'),
                              ('sent', 'Sent'),
                              ('done', 'Done'),
                              ('cancel', 'Cancel')], string='State', readonly=True, default='draft', tracking=True)
    invoice_id = fields.Many2one('account.move', string='Invoice')
    company_id = fields.Many2one('res.company', string='Company')
    invoice_url = fields.Char(string='Invoice Url', tracking=True)
    cufe_cude_uncoded = fields.Char(string='CUFE/CUDE Uncoded', tracking=True)
    cufe_cude = fields.Char(string='CUFE/CUDE', tracking=True)
    origin_cufe_cude = fields.Char(string='CUFE/CUDE original')
    software_security_code_uncoded = fields.Char(string='SoftwareSecurityCode Uncoded', tracking=True)
    software_security_code = fields.Char(string='SoftwareSecurityCode')
    xml_filename = fields.Char(string='XML Filename')
    xml_file = fields.Binary(string='XML File')
    zipped_filename = fields.Char(string='Zipped Filename')
    exp_accepted_file = fields.Binary(string='Explicit Accepted File')
    zip_key = fields.Char(string='ZipKey')
    mail_sent = fields.Boolean(string='Mail Sent?', tracking=True)
    ar_xml_filename = fields.Char(string='ApplicationResponse XML Filename')
    ar_xml_file = fields.Binary(string='ApplicationResponse XML File', tracking=False)
    get_status_zip_status_code = fields.Selection([('00', 'Procesado Correctamente'),
                                                   ('66', 'NSU no encontrado'),
                                                   ('90', 'TrackId no encontrado'),
                                                   ('99', 'Validaciones contienen errores en campos mandatorios'),
                                                   ('other', 'Other')], string='StatusCode', default=False, tracking=True)
    get_status_zip_response = fields.Text(string='Response', tracking=True)
    qr_image = fields.Binary("QR Code", compute='_generate_qr_code')
    dian_document_line_ids = fields.One2many('account.invoice.dian.document.line', 'dian_document_id', string='DIAN Document Lines')
    profile_execution_id = fields.Selection(string='Destination Environment of Document', related='company_id.profile_execution_id', store=False)
    type_account = fields.Selection([('debit', 'Debit Note'),
                                     ('credit', 'Credit Note'),
                                     ('support_document', 'Documento Soporte'),
                                     ('invoice', 'Invoice')])

    def state_to_cancel(self):
        if self.state == 'done' or self.get_status_zip_status_code == '00':
            raise ValidationError(_('No puede cancelar un documento DIAN autorizado'))
        self.state == 'cancel'

    def go_to_dian_document(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Dian Document',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': self._name,
            'res_id': self.id,
            'target': 'current'}

    def _generate_qr_code(self):
        for record in self:
            to_currency = record._get_target_currency()
            if record.invoice_id.move_type in ('out_invoice', 'out_refund'):
                einvoicing_taxes = record.invoice_id._get_einvoicing_taxes(to_currency=to_currency)
                try:
                    ValImp1 = einvoicing_taxes['TaxesTotal']['01']['total']
                except:
                    ValImp1 = 0
                try:
                    ValImp2 = einvoicing_taxes['TaxesTotal']['04']['total']
                except:
                    ValImp2 = 0
                try:
                    ValImp3 = einvoicing_taxes['TaxesTotal']['03']['total']
                except:
                    ValImp3 = 0

                ValFac = record.invoice_id.amount_untaxed
                ValOtroIm = ValImp2 - ValImp3
                ValTolFac = ValFac + ValImp1 + ValImp2 + ValImp3
                date_format = str(record.invoice_id.create_date)[0:19]
                create_date = datetime.strptime(date_format, '%Y-%m-%d %H:%M:%S')
                create_date = create_date.replace(tzinfo=timezone('UTC'))
                nit_fac = record.company_id.partner_id.identification_document
                nit_adq = record.invoice_id.partner_id.identification_document
                cufe = record.cufe_cude
                number = record.invoice_id.name

                qr_data = "NumFac: " + number if number else 'NO_VALIDADA'

                qr_data += "\nNitFac: " + nit_fac if nit_fac else ''
                qr_data += "\nNitAdq: " + nit_adq if nit_adq else ''
                qr_data += "\nValFac: " + '{:.2f}'.format(ValFac)
                qr_data += "\nValIva: " + '{:.2f}'.format(ValImp1)
                qr_data += "\nValOtroIm: " + '{:.2f}'.format(ValOtroIm)
                qr_data += "\nValTolFac: " + '{:.2f}'.format(ValTolFac)
                qr_data += "\nCUFE: " + cufe if cufe else ''
                qr_data += "\n\n" + record.invoice_url if record.invoice_url else ''

            else:
                einvoicing_taxes = record.invoice_id._get_einvoicing_taxes(to_currency=to_currency)
                try:
                    ValImp1 = einvoicing_taxes['TaxesTotal']['01']['total']
                except:
                    ValImp1 = 0

                ValFac = record.invoice_id.amount_untaxed
                ValTolFac = ValFac + ValImp1
                date_format = str(record.invoice_id.create_date)[0:19]
                create_date = datetime.strptime(date_format, '%Y-%m-%d %H:%M:%S')
                create_date = create_date.replace(tzinfo=timezone('UTC'))
                IssueDate = record.invoice_id.invoice_date
                IssueTime = create_date.astimezone(
                    timezone('America/Bogota')).strftime('%H:%M:%S-05:00')
                nit_fac = record.company_id.partner_id.identification_document
                nit_adq = record.invoice_id.partner_id.identification_document
                cufe = record.cufe_cude
                number = record.invoice_id.name

                qr_data = "NumDS: " + number if number else 'NO_VALIDADA'
                qr_data += "\nFecDS: " + str(IssueDate) if IssueDate else ''
                qr_data += "\nHorDS: " + str(IssueTime) if IssueTime else ''
                qr_data += "\nNumSNO: " + nit_fac if nit_fac else ''
                qr_data += "\nNITABS: " + nit_adq if nit_adq else ''
                qr_data += "\nValDS: " + '{:.2f}'.format(ValFac)
                qr_data += "\nValIva: " + '{:.2f}'.format(ValImp1)
                qr_data += "\nValTolDS: " + '{:.2f}'.format(ValTolFac)
                qr_data += "\nCUDS: " + cufe if cufe else ''
                qr_data += "\n" + record.invoice_url if record.invoice_url else ''

            record.qr_image = global_functions.get_qr_code(qr_data)

    def _get_GetStatus_values(self):
        xml_soap_values = global_functions.get_xml_soap_values(
            self.company_id.certificate_file,
            self.company_id.certificate_password)

        xml_soap_values['trackId'] = self.cufe_cude
        return xml_soap_values

    def action_GetStatus(self):
        """
        Anexo pagina 399
        Envia una consulta para obtener el estado del documento en el proceso de validación y devuelve respuesta del estado del documento.
        Se envia trackId: Corresponde al valor del CUFE o TrackId del documento consultado.
        Se recibe: ErrorMessage/String, StatusCode, StatusDescription, StatusMessage, XmlBase64Bytes, XmlBytes, xmlFileName
        """
        wsdl = DIAN['wsdl-hab']

        if self.company_id.profile_execution_id == '1':
            wsdl = DIAN['wsdl']

        # Se obtiene el xml con el trackId
        GetStatus_values = self._get_GetStatus_values()
        GetStatus_values['To'] = wsdl.replace('?wsdl', '')
        # Se firma el xml
        xml_soap_with_signature = global_functions.get_xml_soap_with_signature(
            global_functions.get_template_xml(GetStatus_values, 'GetStatus'),
            GetStatus_values['Id'],
            self.company_id.certificate_file,
            self.company_id.certificate_password
        )

        response = post(
            wsdl,
            headers={'content-type': 'application/soap+xml;charset=utf-8'},
            data=etree.tostring(xml_soap_with_signature, encoding="unicode")
        )

        if response.status_code == 200:
            self._get_status_response(response,send_mail=False)
        else:
            raise ValidationError(response.status_code)

        return True

    def _get_pdf_file(self):
        try:
            msg ='217'
            template = self.env['ir.actions.report'].browse(self.company_id.report_template.id)
            #pdf = self.env.ref('account.move').render_qweb_pdf([self.invoice_id.id])[0]
            if template:
                msg = '221'
                pdf = template._render_qweb_pdf(template.id,self.invoice_id.id)
            else:
                pdf = self.env.ref('account.account_invoices')._render_qweb_pdf(self.invoice_id.id)
                msg = '225'
            pdf = pdf[0]
            msg = '227'
            pdf_name = re.sub(r'\W+', '', self.invoice_id.name) + '.pdf'
            msg = '229'

            #pdf = self.env['ir.actions.report'].sudo()._run_wkhtmltopdf([self.invoice_id.id], template.report_name)
        except Exception as e:
            _logger.error("Error cargando pdf : %s , en la linea %s", e, msg)
        return pdf

    def action_send_mail(self):
        """
        Esta función envía un correo electrónico con una factura adjunta. La factura se adjunta en formato PDF y XML.
        Primero, la función verifica si la factura ha sido validada. Si no es así, se lanza un error. Luego, se genera un archivo XML adjunto y se comprime junto con la factura en PDF en un archivo ZIP. Este archivo ZIP se adjunta al correo electrónico.

        Args:
            self: El registro actual.

        Raises:
            UserError: Si la factura no ha sido validada.

        Side Effects:
            Envía un correo electrónico con la factura adjunta y actualiza el campo 'mail_sent' del registro actual a True.

        Returns:
            True: Si el correo electrónico se envió con éxito.
        """
        try:

            msg = _("Your invoice has not been validated")
            template_id = self.env.ref('l10n_co_e_invoicing.email_template_for_einvoice').id
            template = self.env['mail.template'].browse(template_id)

            if not self.invoice_id.name:
                raise UserError(msg)

            buff = BytesIO()
            zip_file = zipfile.ZipFile(buff, mode='w')
            msg ='259'
            xml_attachment_file = False
            if self.ar_xml_file and self.xml_file:
                # Se genera el xml tipo adjunto
                xml_without_signature = global_functions.get_template_xml(self._get_attachment_values(), 'attachment')
                # Se guarda el xml tipo adjunto
                xml_attachment_file = self.env['ir.attachment'].create({
                    'name': self.xml_filename,
                    'type': 'binary',
                    'datas': b64encode(xml_without_signature.encode()).decode("utf-8", "ignore")}
                )

            # Se comprime el xml tipo adjunto
            if xml_attachment_file:
                zip_content = BytesIO()
                zip_content.write(
                    base64.b64decode(base64.b64encode(xml_without_signature.encode()).decode("utf-8", "ignore")))
                zip_file.writestr(self.xml_filename, zip_content.getvalue())
            msg = '277'
            zip_content = BytesIO()
            # Se comprime la factura en pdf
            zip_content.write(base64.b64decode(base64.b64encode(self._get_pdf_file())))
            msg = '281'
            # Se comprime el contenido del primer zip en el zip principal
            zip_file.writestr(self.xml_filename.replace('.xml', '.pdf'), zip_content.getvalue())
            msg = '283'
            zip_file.close()
            zipped_file = base64.b64encode(buff.getvalue())
            buff.close()
            msg = '287'
            # Se crea un archivo zip con el xml tipo adjunto y la factura en pdf
            attachment = self.env['ir.attachment'].create({
                'name': self.xml_filename.replace('.xml', '.zip'),
                'type': 'binary',
                'datas': zipped_file,
            })
            msg = '294'
            attach_ids = [attachment.id]

            # Si es una factura de venta o una factura de exportación se adjunta el adjunto a la plantilla de correo
            if self.invoice_id.invoice_type_code in ('01', '02'):
                template.attachment_ids = [(6, 0, attach_ids)]
            else:
                template.attachment_ids = [(6, 0, attach_ids)]

            template.attachment_ids = [(6, 0, attach_ids)]
            # Se envia el correo con el adjunto
            template.send_mail(self.invoice_id.id, force_send=True)
            self.write({'mail_sent': True})
        except Exception as e:
            _logger.error("Error enviando correo : %s , en la linea %s", e, msg)
        finally:    
            return True

    def _get_status_response(self, response, send_mail):
        """
        Analiza la respuesta XML, extrae el código de estado y realiza varias acciones dependiendo del código de estado.
        También extrae y guarda cualquier mensaje de estado y contenido XML en base64.

        Args:
            self: El registro actual.
            response (requests.Response): La respuesta de la solicitud de estado.
            send_mail (bool): Un indicador de si se debe enviar un correo electrónico en caso de fallo.

        Returns:
            bool: Siempre devuelve True.
        """
        b = "http://schemas.datacontract.org/2004/07/DianResponse"
        c = "http://schemas.microsoft.com/2003/10/Serialization/Arrays"
        s = "http://www.w3.org/2003/05/soap-envelope"
        strings = ''
        to_return = True
        status_code = 'other'
        root = etree.fromstring(response.content)
        date_invoice = self.invoice_id.invoice_date

        if not date_invoice:
            date_invoice = fields.Date.today()

        for element in root.iter("{%s}StatusCode" % b):
            # Anexo pagina 338
            # Si el error es alguno de los conodicos
            # 00 = Procesado Correctamente
            # 66= NSU no encontrado
            # 90 = TrackId no encontrado
            # 99 = validaciones contienen errores en campos mandatorios
            if element.text in ('0', '00', '66', '90', '99'):
                # Si fue procesado correctamente
                if element.text == '00':
                    self.write({'state': 'done'})

                    # Si el codigo de estado del registro no fue procesado correctamente
                    if self.get_status_zip_status_code != '00':
                        if (self.invoice_id.move_type == "out_invoice" and not self.invoice_id.refund_type):
                            self.company_id.out_invoice_sent += 1
                        elif (self.invoice_id.move_type == "out_refund" and self.invoice_id.refund_type != "debit"):
                            self.company_id.out_refund_sent += 1
                        elif (self.invoice_id.move_type == "out_invoice" and self.invoice_id.refund_type == "debit"):
                            self.company_id.out_refund_sent += 1

                status_code = element.text
        if status_code == '0':
            self.action_GetStatus()

            return True

        if status_code == '00':
            for element in root.iter("{%s}StatusMessage" % b):
                strings = element.text

            for element in root.iter("{%s}XmlBase64Bytes" % b):
                self.write({'ar_xml_file': element.text})

            if not self.mail_sent:
                self.action_send_mail()
            to_return = True
        else:
            if send_mail:
                self.send_failure_email()
            self.send_failure_email()
            to_return = True

        for element in root.iter("{%s}string" % c):
            if strings == '':
                strings = '- ' + element.text
            else:
                strings += '\n\n- ' + element.text

        if strings == '':
            for element in root.iter("{%s}Body" % s):
                strings = etree.tostring(element, pretty_print=True)

            if strings == '':
                strings = etree.tostring(root, pretty_print=True)

        self.write({
            'get_status_zip_status_code': status_code,
            'get_status_zip_response': strings}
        )

        return True

    def send_failure_email(self):
        msg1 = _("The notification group for Einvoice failures is not set.\n" +
                 "You won't be notified if something goes wrong.\n" +
                 "Please go to Settings > Company > Notification Group.")
        subject = _('ALERTA! La Factura %s no fue enviada a la DIAN.') % self.invoice_id.name
        msg_body = _('''Cordial Saludo,<br/><br/>La factura ''' + self.invoice_id.name +
                     ''' del cliente ''' + self.invoice_id.partner_id.name + ''' no pudo ser ''' +
                     '''enviada a la Dian según el protocolo establecido previamente. Por '''
                     '''favor revise el estado de la misma en el menú Documentos Dian e '''
                     '''intente reprocesarla según el procedimiento definido.'''
                     '''<br/>''' + self.company_id.name + '''.''')
        email_ids = self.company_id.notification_group_ids

        if email_ids:
            email_to = ''

            for mail_id in email_ids:
                email_to += mail_id.email.strip() + ','
        else:
            raise UserError(msg1)

        mail_obj = self.env['mail.mail']
        msg_vals = {
            'subject': subject,
            'email_to': email_to,
            'body_html': msg_body}
        msg_id = mail_obj.create(msg_vals)
        msg_id.send()

        return True

    def _set_filenames(self):
        """
        Esta función genera nombres de archivo para un archivo XML y un archivo ZIP basados en las especificaciones de la DIAN (Dirección de Impuestos y Aduanas Nacionales de Colombia).
        Los nombres de archivo se generan utilizando el NIT del facturador electrónico, el código de software, el año calendario y un consecutivo de paquetes de archivos enviados.

        Args:
            self: El registro actual.

        Raises:
            ValidationError: Si el documento de identificación de la compañía no está establecido en el socio.

        Side Effects:
            Actualiza los campos 'xml_filename' y 'zipped_filename' del registro actual con los nombres de archivo generados.
        """
        #nnnnnnnnnn: NIT del Facturador Electrónico sin DV, de diez (10) dígitos
        # alineados a la derecha y relleno con ceros a la izquierda.
        if self.company_id.partner_id.identification_document:
            nnnnnnnnnn = self.company_id.partner_id.identification_document.zfill(10)
        else:
            raise ValidationError("The company identification document is not "
                                  "established in the partner.\n\nGo to Contacts > "
                                  "[Your company name] to configure it.")
        #El Código “ppp” es 000 para Software Propio
        ppp = '000'
        #aa: Dos (2) últimos dígitos año calendario
        aa = datetime.now().replace(
            tzinfo=timezone('America/Bogota')).strftime('%y')
        #dddddddd: consecutivo del paquete de archivos comprimidos enviados;
        # de ocho (8) dígitos decimales alineados a la derecha y ajustado a la
        # izquierda con ceros; en el rango:
        #   00000001 <= 99999999
        # Ejemplo de la décima primera factura del Facturador Electrónico con
        # NIT 901138658 con software propio para el año 2019.
        # Regla: el consecutivo se iniciará en “00000001” cada primero de enero.
        out_invoice_sent = self.company_id.out_invoice_sent
        out_refund_sent = self.company_id.out_refund_sent
        in_refund_sent = self.company_id.in_refund_sent
        zip_sent = out_invoice_sent + out_refund_sent + in_refund_sent

        if self.invoice_id.move_type == 'out_invoice' and not self.invoice_id.refund_type:
            xml_filename_prefix = 'fv'
            dddddddd = str(out_invoice_sent + 1).zfill(8)
        elif self.invoice_id.move_type == 'out_refund' and self.invoice_id.refund_type != 'debit':
            xml_filename_prefix = 'nc'
            dddddddd = str(out_refund_sent + 1).zfill(8)
        elif self.invoice_id.move_type == 'out_invoice' and self.invoice_id.refund_type == 'debit':
            xml_filename_prefix = 'nd'
            dddddddd = str(out_refund_sent + 1).zfill(8)
        elif self.invoice_id.move_type == 'in_invoice':
            xml_filename_prefix = 'ds'
            dddddddd = str(out_invoice_sent + 1).zfill(8)
        elif self.invoice_id.move_type == 'in_refund':
            xml_filename_prefix = 'rds'
            dddddddd = str(out_invoice_sent + 1).zfill(8)

        # elif self.invoice_id.type == 'out_refund':
        #     xml_filename_prefix = 'nc'
        #     dddddddd = str(out_refund_sent + 1).zfill(8)
        # elif self.invoice_id.type == 'in_refund':
        #     xml_filename_prefix = 'nd'
        #     dddddddd = str(in_refund_sent + 1).zfill(8)
        #pendiente
        #arnnnnnnnnnnpppaadddddddd.xml
        #adnnnnnnnnnnpppaadddddddd.xml
        else:
            raise ValidationError("ERROR: TODO")

        zdddddddd = str(zip_sent + 1).zfill(8)
        nnnnnnnnnnpppaadddddddd = nnnnnnnnnn + ppp + aa + dddddddd
        znnnnnnnnnnpppaadddddddd = nnnnnnnnnn + ppp + aa + zdddddddd

        self.write({
            'xml_filename': xml_filename_prefix + nnnnnnnnnnpppaadddddddd + '.xml',
            'zipped_filename': 'z' + znnnnnnnnnnpppaadddddddd + '.zip'})

    def _get_xml_suppplier_values(self, ClTec):
        msg7 = _('The Incoterm is not defined for this export type invoice')

        to_currency = self._get_target_currency()
        active_dian_resolution = self.invoice_id._get_active_dian_resolution()
        einvoicing_taxes = self.invoice_id._get_einvoicing_taxes(to_currency=to_currency)
        date_format = str(self.invoice_id.create_date)[0:19]
        create_date = datetime.strptime(date_format, '%Y-%m-%d %H:%M:%S')
        create_date = create_date.replace(tzinfo=timezone('UTC'))
        ID = self.invoice_id.name
        IssueDate = self.invoice_id.invoice_date
        IssueTime = create_date.astimezone(
            timezone('America/Bogota')).strftime('%H:%M:%S-05:00')

        LossRiskResponsibilityCode = self.invoice_id.invoice_incoterm_id.code or ''
        LossRisk = self.invoice_id.invoice_incoterm_id.name or ''
        if self.invoice_id.invoice_type_code == '02':
            if not self.invoice_id.invoice_incoterm_id:
                raise UserError(msg7)
            elif not self.invoice_id.invoice_incoterm_id.name or not self.invoice_id.invoice_incoterm_id.code:
                raise UserError('Incoterm is not properly parameterized')
            else:
                LossRiskResponsibilityCode = self.invoice_id.invoice_incoterm_id.code
                LossRisk = self.invoice_id.invoice_incoterm_id.name

        supplier = self.company_id.partner_id
        customer = self.invoice_id.partner_id
        NitOFE = supplier.identification_document
        NitAdq = customer.identification_document

        ClTec = False
        SoftwarePIN = False
        IdSoftware = self.company_id.software_id

        if self.invoice_id.move_type == 'out_invoice' and not self.invoice_id.refund_type:
            ClTec = active_dian_resolution['technical_key']
        else:
            SoftwarePIN = self.company_id.software_pin

        TipoAmbie = self.company_id.profile_execution_id

        if TipoAmbie == '1':
            QRCodeURL = DIAN['catalogo']
        else:
            QRCodeURL = DIAN['catalogo-hab']

        ValFac = self.invoice_id.amount_untaxed
        try:
            ValImp1 = einvoicing_taxes['TaxesTotal']['01']['total']
        except:
            ValImp1 = 0
        try:
            ValImp2 = einvoicing_taxes['TaxesTotal']['04']['total']
        except:
            ValImp2 = 0
        try:
            ValImp3 = einvoicing_taxes['TaxesTotal']['03']['total']
        except:
            ValImp3 = 0
        TaxInclusiveAmount = ValFac + ValImp1 + ValImp2 + ValImp3
        # El valor a pagar puede verse afectado, por anticipos, y descuentos y
        # cargos a nivel de factura
        PayableAmount = TaxInclusiveAmount
        cufe_cude = global_functions.get_cuds(
            ID,
            IssueDate,
            IssueTime,
            str('{:.2f}'.format(ValFac)),
            '01',
            str('{:.2f}'.format(ValImp1)),
            str('{:.2f}'.format(TaxInclusiveAmount)),  # self.invoice_id.amount_total
            NitAdq,
            NitOFE,
            SoftwarePIN,
            TipoAmbie)
        software_security_code = global_functions.get_software_security_code(
            IdSoftware,
            self.company_id.software_pin,
            ID)
        partition_key = 'co|' + str(IssueDate).split('-')[2] + '|' + cufe_cude['CUFE/CUDE'][:2]
        emission_date = str(IssueDate).replace('-', '')
        QRCodeURL = QRCodeURL.format(cufe_cude['CUFE/CUDE'], partition_key, emission_date)

        self.write({
            'invoice_url': QRCodeURL,
            'cufe_cude_uncoded': cufe_cude['CUFE/CUDEUncoded'],
            'cufe_cude': cufe_cude['CUFE/CUDE'],
            'software_security_code_uncoded':
                software_security_code['SoftwareSecurityCodeUncoded'],
            'software_security_code':
                software_security_code['SoftwareSecurityCode']})
        return {
            'InvoiceAuthorization': active_dian_resolution['resolution_number'],
            'StartDate': active_dian_resolution['date_from'],
            'EndDate': active_dian_resolution['date_to'],
            'Prefix': active_dian_resolution['prefix'],
            'From': active_dian_resolution['number_from'],
            'To': active_dian_resolution['number_to'],
            'ProviderIDschemeID': supplier.check_digit,
            'ProviderIDschemeName': supplier.document_type_id.code,
            'ProviderID': NitOFE,
            'NitAdquiriente': NitAdq,
            'SoftwareID': IdSoftware,
            'SoftwareSecurityCode': software_security_code['SoftwareSecurityCode'],
            'QRCodeURL': QRCodeURL,
            'ProfileExecutionID': TipoAmbie,
            'ID': ID,
            'UUID': cufe_cude['CUFE/CUDE'],
            'IssueDate': IssueDate,
            'IssueTime': IssueTime,
            'LineCountNumeric': len(self.invoice_id.invoice_line_ids.filtered(
                lambda x: x.display_type not in ('line_section', 'line_note'))),
            'DocumentCurrencyCode': self.invoice_id.currency_id.name, # FAD15
            'Delivery': customer._get_delivery_values(),
            'DeliveryTerms': {'LossRiskResponsibilityCode': LossRiskResponsibilityCode, 'LossRisk': LossRisk},
            'AccountingSupplierParty': supplier._get_accounting_partner_party_values(self.company_id),
            'AccountingCustomerParty': customer._get_accounting_partner_party_values(self.company_id),
            # TODO: No esta completamente calro los datos de que tercero son
            'TaxRepresentativeParty': supplier._get_tax_representative_party_values(),
            'InformationContentProviderParty': self.invoice_id.mandante_id._get_tax_representative_party_values() if self.invoice_id.mandante_id else {},
            'PaymentMeansID': self.invoice_id.payment_mean_id.code,
            'PaymentMeansCode': self.invoice_id.payment_mean_code_id.code or '10',
            # 'PaymentMeansCode': self.invoice_id.payment_mean_code_id,
            # 'PaymentDueDate': self.invoice_id.date_due,
            'DueDate': self.invoice_id.invoice_date_due,
            'PaymentExchangeRate': self.invoice_id._get_payment_exchange_rate(), # FAR01
            'PaymentDueDate': self.invoice_id.invoice_date_due,
            'TaxesTotal': einvoicing_taxes['TaxesTotal'],
            'WithholdingTaxesTotal': einvoicing_taxes['WithholdingTaxesTotal'],
            'LineExtensionAmount': '{:.2f}'.format(self.invoice_id.amount_untaxed),
            'TaxExclusiveAmount': '{:.2f}'.format(self.invoice_id.amount_untaxed),
            'TaxInclusiveAmount': '{:.2f}'.format(TaxInclusiveAmount),  # ValTot
            'PayableAmount': '{:.2f}'.format(PayableAmount),
            'OrderReference': self.invoice_id.orden_compra or '',
        }

    def _get_target_currency(self):
        # Anexo 1.9 ya no acepta multiples monedas para facturas de venta
        if self.invoice_id.move_type in ('out_invoice', 'in_invoice', 'out_refund', 'in_refund'):
            cop_currency = self.env['res.currency'].search([('name', '=', 'COP')], limit=1)

            return cop_currency
        else:
            return self.invoice_id.currency_id

    def _get_xml_values(self, ClTec):
        msg7 = _('The Incoterm is not defined for this export type invoice')

        documentCurrencyCode = self.invoice_id.currency_id.name
        amount_untaxed = self.invoice_id.amount_untaxed
        to_currency = self._get_target_currency()


        amount_untaxed = self.invoice_id.currency_id._convert(
            self.invoice_id.amount_untaxed, to_currency, self.company_id, self.invoice_id.invoice_date)

        active_dian_resolution = self.invoice_id._get_active_dian_resolution()
        einvoicing_taxes = self.invoice_id._get_einvoicing_taxes(to_currency=to_currency)
        date_format = str(self.invoice_id.create_date)[0:19]
        create_date = datetime.strptime(date_format, '%Y-%m-%d %H:%M:%S')
        create_date = create_date.replace(tzinfo=timezone('UTC'))
        ID = self.invoice_id.name

        IssueDate = self.invoice_id.invoice_date

        # Si el documento se está transmitiendo un día diferente a la fecha de factura
        if self.get_status_zip_response and ('CAD09e' in self.get_status_zip_response or 'FAD09e' in self.get_status_zip_response ):
            IssueDate = fields.Date.today()

        IssueTime = create_date.astimezone(
            timezone('America/Bogota')).strftime('%H:%M:%S-05:00')

        LossRiskResponsibilityCode = self.invoice_id.invoice_incoterm_id.code or ''
        LossRisk = self.invoice_id.invoice_incoterm_id.name or ''
        if self.invoice_id.invoice_type_code == '02':
            if not self.invoice_id.invoice_incoterm_id:
                raise UserError(msg7)
            elif not self.invoice_id.invoice_incoterm_id.name or not self.invoice_id.invoice_incoterm_id.code:
                raise UserError('Incoterm is not properly parameterized')
            else:
                LossRiskResponsibilityCode = self.invoice_id.invoice_incoterm_id.code
                LossRisk = self.invoice_id.invoice_incoterm_id.name

        supplier = self.company_id.partner_id
        customer = self.invoice_id.partner_id
        NitOFE = supplier.identification_document
        NitAdq = customer.identification_document

        ClTec = False
        SoftwarePIN = False
        IdSoftware = self.company_id.software_id

        if self.invoice_id.move_type == 'out_invoice' and not self.invoice_id.refund_type:
            ClTec = active_dian_resolution['technical_key']
        else:
            SoftwarePIN = self.company_id.software_pin

        TipoAmbie = self.company_id.profile_execution_id

        if TipoAmbie == '1':
            QRCodeURL = DIAN['catalogo']
        else:
            QRCodeURL = DIAN['catalogo-hab']

        ValFac = self.invoice_id.currency_id._convert(
            self.invoice_id.amount_untaxed, to_currency, self.company_id, self.invoice_id.invoice_date)
        try:
            ValImp1 = einvoicing_taxes['TaxesTotal']['01']['total']
        except:
            ValImp1 = 0
        try:
            ValImp2 = einvoicing_taxes['TaxesTotal']['04']['total']
        except:
            ValImp2 = 0
        try:
            ValImp3 = einvoicing_taxes['TaxesTotal']['03']['total']
        except:
            ValImp3 = 0

        AllowanceTotalAmount = 0 # Suma de todos los descuentos globales
        ChargeTotalAmount = 0 # Suma de todos los cargos globales

        ## Comprobar si el valor total de LineExtensionAmount es igual a la suma de los valores de las lineas
        lines = self.invoice_id._get_invoice_lines(to_currency)
        total = 0

        for invoiceLineId, line in lines.items():
            total += float(line.get('LineExtensionAmount', 0))

        # Solo se envía este dato si es una nota, no para facturas,  por el error que estaba generando con FAU14
        PayableRoundingAmount = abs(float(amount_untaxed) - total) if self.invoice_id.move_type not in (
            'out_invoice') else 0

        TaxInclusiveAmount = round(ValFac + ValImp1 + ValImp2 + ValImp3, 2) # Valor de la factura con impuestos
        # Descuento Total: Suma de todos los descuentos aplicados a nivel de la factura
        #El valor a pagar puede verse afectado, por anticipos, y descuentos y cargos
        #El Valor de la Factura es igual a la Suma de Valor Bruto más tributos - Valor del Descuento Total + Valor del Cargo Total a nivel de factura
        PayableAmount = round(TaxInclusiveAmount - AllowanceTotalAmount + ChargeTotalAmount, 2)

        cufe_cude = global_functions.get_cufe_cude(
            ID,
            IssueDate,
            IssueTime,
            str('{:.2f}'.format(ValFac)),
            '01',
            str('{:.2f}'.format(float(ValImp1))),
            '04',
            str('{:.2f}'.format(ValImp2)),
            '03',
            str('{:.2f}'.format(ValImp3)),
            str('{:.2f}'.format(TaxInclusiveAmount)),#self.invoice_id.amount_total
            NitOFE, # Nit de la empresa
            NitAdq, # Nit del cliente
            ClTec, # Clave tecnica o sofware id
            SoftwarePIN,
            TipoAmbie
        )
        software_security_code = global_functions.get_software_security_code(
            IdSoftware,
            self.company_id.software_pin,
            ID)
        partition_key = 'co|' + str(IssueDate).split('-')[2] + '|' + cufe_cude['CUFE/CUDE'][:2]
        emission_date = str(IssueDate).replace('-', '')
        QRCodeURL = QRCodeURL.format(cufe_cude['CUFE/CUDE'], partition_key, emission_date)
        documentCurrencyCode = to_currency.name

        self.write({
            'invoice_url': QRCodeURL,
            'cufe_cude_uncoded': cufe_cude['CUFE/CUDEUncoded'],
            'cufe_cude': cufe_cude['CUFE/CUDE'],
            'software_security_code_uncoded':
                software_security_code['SoftwareSecurityCodeUncoded'],
            'software_security_code':
                software_security_code['SoftwareSecurityCode']})
        return {
            'start_invoice_period': self.invoice_id.start_invoice_period,
            'end_invoice_period': self.invoice_id.end_invoice_period,
            'InvoiceAuthorization': active_dian_resolution['resolution_number'],
            'StartDate': active_dian_resolution['date_from'],
            'EndDate': active_dian_resolution['date_to'],
            'Prefix': active_dian_resolution['prefix'],
            'From': active_dian_resolution['number_from'],
            'To': active_dian_resolution['number_to'],
            'ProviderIDschemeID': supplier.check_digit,
            'ProviderIDschemeName': supplier.document_type_id.code,
            'ProviderID': NitOFE,
            'NitAdquiriente': NitAdq,
            'SoftwareID': IdSoftware,
            'SoftwareSecurityCode': software_security_code['SoftwareSecurityCode'],
            'QRCodeURL': QRCodeURL,
            'ProfileExecutionID': TipoAmbie,
            'ID': ID,
            'UUID': cufe_cude['CUFE/CUDE'],
            'IssueDate': IssueDate,
            'IssueTime': IssueTime,
            'LineCountNumeric': len(self.invoice_id.invoice_line_ids.filtered(lambda x: x.display_type in ['product'])),
            'DocumentCurrencyCode': documentCurrencyCode,
            'Delivery': customer._get_delivery_values(),
            'DeliveryTerms': {'LossRiskResponsibilityCode': LossRiskResponsibilityCode, 'LossRisk': LossRisk},
            'AccountingSupplierParty': supplier._get_accounting_partner_party_values(self.company_id),
            'AccountingCustomerParty': customer._get_accounting_partner_party_values(self.company_id),
            # TODO: No esta completamente calro los datos de que tercero son
            'TaxRepresentativeParty': supplier._get_tax_representative_party_values(),
            'InformationContentProviderParty': self.invoice_id.mandante_id._get_tax_representative_party_values() if self.invoice_id.mandante_id else {},
            'PaymentMeansID': self.invoice_id.payment_mean_id.code,
            'PaymentMeansCode': self.invoice_id.payment_mean_code_id.code or '10',
            #'PaymentMeansCode': self.invoice_id.payment_mean_code_id,
            #'PaymentDueDate': self.invoice_id.date_due,
            'DueDate': self.invoice_id.invoice_date_due,
            'PaymentExchangeRate': self.invoice_id._get_payment_exchange_rate(),
            'PaymentDueDate': self.invoice_id.invoice_date_due,
            'TaxesTotal': einvoicing_taxes['TaxesTotal'],
            'WithholdingTaxesTotal': einvoicing_taxes['WithholdingTaxesTotal'],
            'LineExtensionAmount': '{:.2f}'.format(amount_untaxed), # FAU02
            'TaxExclusiveAmount': '{:.2f}'.format(amount_untaxed), # FAU04
            'TaxInclusiveAmount': '{:.2f}'.format(TaxInclusiveAmount),#ValTot
            'PayableAmount': '{:.2f}'.format(PayableAmount),
            'PayableRoundingAmount': '{:.2f}'.format(PayableRoundingAmount),
            'OrderReference': self.invoice_id.orden_compra or '',
            }

    def _get_accuse_recibo_values(self):
        xml_values = self._get_xml_suppplier_values(False)
        xml_values['CustomizationID'] = self.invoice_id.operation_type
        active_dian_resolution = self.invoice_id._get_active_dian_resolution()
        xml_values['InvoiceControl'] = active_dian_resolution
        xml_values['InvoiceTypeCode'] = self.invoice_id.invoice_type_code
        xml_values['InvoiceLines'] = self.invoice_id._get_invoice_lines()
        xml_values['UUID'] = self.invoice_id.cufe_cude
        return xml_values

    def _get_accepted_values(self):
        xml_values = self._get_xml_values(False)
        xml_values['CustomizationID'] = self.invoice_id.operation_type
        active_dian_resolution = self.invoice_id._get_active_dian_resolution()
        xml_values['InvoiceControl'] = active_dian_resolution
        xml_values['InvoiceTypeCode'] = self.invoice_id.invoice_type_code
        xml_values['InvoiceLines'] = self.invoice_id._get_invoice_lines()
        return xml_values

    def _get_invoice_values(self):
        xml_values = self._get_xml_values(False)
        #Punto 14.1.5.1. del anexo tecnico version 1.8
        #10 Estandar *
        #09 AIU
        #11 Mandatos
        #xml_values['CustomizationID'] = '10'
        xml_values['CustomizationID'] = self.invoice_id.operation_type
        active_dian_resolution = self.invoice_id._get_active_dian_resolution()

        xml_values['InvoiceControl'] = active_dian_resolution
        #Tipos de factura
        #Punto 14.1.3 del anexo tecnico version 1.8
        #01 Factura de Venta
        #02 Factura de Exportación
        #03 Factura por Contingencia Facturador
        #04 Factura por Contingencia DIAN
        xml_values['InvoiceTypeCode'] = self.invoice_id.invoice_type_code

        to_currency = self._get_target_currency()

        xml_values['InvoiceLines'] = self.invoice_id._get_invoice_lines(to_currency=to_currency)

        return xml_values

    def _get_attachment_values(self):
        xml_values = self._get_xml_values(False)
        #Punto 14.1.5.1. del anexo tecnico version 1.8
        #10 Estandar *
        #09 AIU
        #11 Mandatos
        #xml_values['CustomizationID'] = '10'
        xml_values['CustomizationID'] = self.invoice_id.operation_type
        active_dian_resolution = self.invoice_id._get_active_dian_resolution()

        xml_values['InvoiceControl'] = active_dian_resolution
        #Tipos de factura
        #Punto 14.1.3 del anexo tecnico version 1.8
        #01 Factura de Venta
        #02 Factura de Exportación
        #03 Factura por Contingencia Facturador
        #04 Factura por Contingencia DIAN
        xml_values['InvoiceTypeCode'] = self.invoice_id.invoice_type_code
        xml_values['InvoiceLines'] = self.invoice_id._get_invoice_lines()
        xml_values['ApplicationResponse'] = b64decode(self.ar_xml_file).decode("utf-8", "ignore")
        xml_values['xml_file'] = b64decode(self.xml_file).decode("utf-8", "ignore")

        return xml_values

    def _get_credit_note_values(self):
        to_currency = self._get_target_currency()

        xml_values = self._get_xml_values(False)
        if self.invoice_id.operation_type == '10' or self.invoice_id.reversed_entry_id:
            billing_reference = self.invoice_id._get_billing_reference()
        else:
            billing_reference = False

        #Punto 14.1.5.2. del anexo tecnico version 1.8
        #20 Nota Crédito que referencia una factura electrónica.
        #22 Nota Crédito sin referencia a facturas*.
        #23 Nota Crédito para facturación electrónica V1 (Decreto 2242).
        if billing_reference:
            xml_values['CustomizationID'] = '20'
            self.invoice_id.operation_type = '20'
        elif self.invoice_id.operation_type == '22':
            xml_values['CustomizationID'] = '22'
            self.invoice_id.operation_type = '22'
            billing_reference = {
                'ID': False,
                'UUID': False,
                'IssueDate': False,
                'CustomizationID': False}
        else:
            xml_values['CustomizationID'] = '20'
            self.invoice_id.operation_type = '20'
            billing_reference = {
                'ID': self.invoice_id.id_invoice_refound,
                'UUID': self.invoice_id.uuid_invoice,
                'IssueDate': self.invoice_id.issue_date_invoice or '',
                'CustomizationID': self.invoice_id.customizationid_invoice}

        #TODO 2.0: Exclusivo en referencias a documentos (elementos DocumentReference)
        #Punto 14.1.3 del anexo tecnico version 1.8
        #91 Nota Crédito
        xml_values['CreditNoteTypeCode'] = '91'
        xml_values['BillingReference'] = billing_reference
        xml_values['DiscrepancyReferenceID'] = billing_reference['ID']
        xml_values['DiscrepancyResponseCode'] = self.invoice_id.discrepancy_response_code_id.code
        xml_values['DiscrepancyDescription'] = self.invoice_id.discrepancy_response_code_id.name
        xml_values['CreditNoteLines'] = self.invoice_id._get_invoice_lines(to_currency)
        return xml_values

    def _get_debit_note_values(self):
        xml_values = self._get_xml_values(False)
        if self.invoice_id.operation_type == '10' or self.invoice_id.debit_origin_id:
            billing_reference = self.invoice_id._get_billing_reference()
        else:
            billing_reference = False

        #Punto 14.1.5.3. del anexo tecnico version 1.8
        #30 Nota Débito que referencia una factura electrónica.
        #32 Nota Débito sin referencia a facturas *.
        #33 Nota Débito para facturación electrónica V1 (Decreto 2242).

        if billing_reference:
            xml_values['CustomizationID'] = '30'
            self.invoice_id.operation_type = '30'
        elif self.invoice_id.operation_type == '32':
            xml_values['CustomizationID'] = '32'
            self.invoice_id.operation_type = '32'
            billing_reference = {
                'ID': False,
                'UUID': False,
                'IssueDate': False,
                'CustomizationID': False}
        else:
            xml_values['CustomizationID'] = '30'
            self.invoice_id.operation_type = '30'
            billing_reference = {
                'ID': self.invoice_id.id_invoice_refound,
                'UUID': self.invoice_id.uuid_invoice,
                'IssueDate': self.invoice_id.issue_date_invoice,
                'CustomizationID': self.invoice_id.customizationid_invoice}
        #Exclusivo en referencias a documentos (elementos DocumentReference)
        #Punto 14.1.3 del anexo tecnico version 1.8
        #92 Nota Débito
        #TODO 2.0: DebitNoteTypeCode no existe en DebitNote
        #xml_values['DebitNoteTypeCode'] = '92'
        xml_values['BillingReference'] = billing_reference
        xml_values['DiscrepancyReferenceID'] = billing_reference['ID']
        xml_values['DiscrepancyResponseCode'] = self.invoice_id.discrepancy_response_code_id.code
        xml_values['DiscrepancyDescription'] = self.invoice_id.discrepancy_response_code_id.name
        xml_values['DebitNoteLines'] = self.invoice_id._get_invoice_lines()
        return xml_values

    def accuse_recibo(self):
        accepted_xml_without_signature = global_functions.get_template_xml(self._get_accuse_recibo_values(),'AcuseRecibo')
        accepted_xml_with_signature = global_functions.get_xml_with_signature(accepted_xml_without_signature, self.company_id.signature_policy_url, self.company_id.signature_policy_description, self.company_id.certificate_file, self.company_id.certificate_password)
        self.write({'exp_accepted_file': b64encode(self._get_acp_zipped_file(accepted_xml_with_signature)).decode("utf-8", "ignore")})
        self.action_sent_accepted_file(self.exp_accepted_file)
        # Se generan el xml y el zip de la factura
        self.action_set_files()
        self.action_sent_zipped_file()

    def bs_acceptation(self):
        accepted_xml_without_signature = global_functions.get_template_xml(self._get_accepted_values(), 'ReciboBS')
        accepted_xml_with_signature = global_functions.get_xml_with_signature(accepted_xml_without_signature, self.company_id.signature_policy_url, self.company_id.signature_policy_description, self.company_id.certificate_file, self.company_id.certificate_password)
        self.write({'exp_accepted_file': b64encode(self._get_acp_zipped_file(accepted_xml_with_signature)).decode(
            "utf-8", "ignore")})
        self.action_sent_accepted_file(self.exp_accepted_file)

    def express_acceptation(self):
        accepted_xml_without_signature = global_functions.get_template_xml(self._get_accepted_values(),'AceptacionExpresa')
        accepted_xml_with_signature = global_functions.get_xml_with_signature(accepted_xml_without_signature, self.company_id.signature_policy_url, self.company_id.signature_policy_description, self.company_id.certificate_file, self.company_id.certificate_password)
        self.write({'exp_accepted_file': b64encode(self._get_acp_zipped_file(accepted_xml_with_signature)).decode("utf-8", "ignore")})
        self.action_sent_accepted_file(self.exp_accepted_file)
        self.bs_acceptation()

    def refund_acceptation(self):
        accepted_xml_without_signature = global_functions.get_template_xml(self._get_accepted_values(), 'ReclamoEI')
        accepted_xml_with_signature = global_functions.get_xml_with_signature(accepted_xml_without_signature, self.company_id.signature_policy_url, self.company_id.signature_policy_description, self.company_id.certificate_file, self.company_id.certificate_password)
        self.write({'exp_accepted_file': b64encode(self._get_acp_zipped_file(accepted_xml_with_signature)).decode("utf-8", "ignore")})
        self.action_sent_accepted_file(self.exp_accepted_file)

    def _get_xml_file(self):
        """
        Genera un archivo XML con firma para una factura, nota de crédito, nota de débito o documento de soporte, dependiendo del tipo de movimiento de la factura.
        La función primero determina el tipo de movimiento de la factura y, en función de eso, genera un XML sin firma utilizando la función de plantilla XML correspondiente.
        Luego, firma el XML utilizando la política de firma, el archivo de certificado y la contraseña del certificado de la compañía.

        Args:
            self: El registro actual.

        Returns:
            xml_with_signature: El archivo XML con firma.
        """
        # if self.invoice_id.type == "out_invoice":
        #     xml_without_signature = global_functions.get_template_xml(
        #         self._get_invoice_values(),
        #         'Invoice')
        # elif self.invoice_id.type == "out_refund":
        #     xml_without_signature = global_functions.get_template_xml(
        #         self._get_credit_note_values(),
        #         'CreditNote')
        # elif self.invoice_id.type == "in_refund":
        #     xml_without_signature = global_functions.get_template_xml(
        #         self._get_debit_note_values(),
        #         'DebitNote')

        if self.invoice_id.move_type == "out_invoice" and not self.invoice_id.refund_type:
            xml_without_signature = global_functions.get_template_xml(
                self._get_invoice_values(),
                'Invoice')
        elif self.invoice_id.move_type == "out_refund" and self.invoice_id.refund_type != "debit":
            xml_without_signature = global_functions.get_template_xml(
                self._get_credit_note_values(),
                'CreditNote')
        elif self.invoice_id.move_type == "out_invoice" and self.invoice_id.refund_type == "debit":
            xml_without_signature = global_functions.get_template_xml(
                self._get_debit_note_values(),
                'DebitNote')
        elif self.invoice_id.move_type == "in_invoice":
            xml_without_signature = global_functions.get_template_xml(self._get_support_values(), 'SupportDocument')
        elif self.invoice_id.move_type == "in_refund":
            xml_without_signature = global_functions.get_template_xml(self._get_support_values(), 'SupportDocumentCredit')

        xml_with_signature = global_functions.get_xml_with_signature(
            xml_without_signature,
            self.company_id.signature_policy_url,
            self.company_id.signature_policy_description,
            self.company_id.certificate_file,
            self.company_id.certificate_password)

        return xml_with_signature

    def _get_acp_zipped_file(self, file):
        output = BytesIO()
        zipfile = ZipFile(output, mode='w')
        zipfile_content = BytesIO()
        zipfile_content.write(b64decode(file))
        zipfile.writestr(self.xml_filename, zipfile_content.getvalue())
        zipfile.close()
        return output.getvalue()

    def _get_zipped_file(self):
        """
        Comprime el archivo XML con firma y lo devuelve como un conjunto de bytes.
        """
        output = BytesIO()
        zipfile = ZipFile(output, mode='w')
        zipfile_content = BytesIO()
        zipfile_content.write(b64decode(self.xml_file))
        zipfile.writestr(self.xml_filename, zipfile_content.getvalue())
        zipfile.close()
        return output.getvalue()

    def action_set_files(self):
        """
        Si no se ha generado el nombre del archivo XML o el nombre del archivo comprimido
        Se genera según especificaciones de la DIAN y se almacenan en los campos xml_filename y zipped_filename.
        """

        if not self.xml_filename or not self.zipped_filename:
            self._set_filenames()

        # Se genera el archivo XML con firma y se guarda en el campo xml_file.
        self.write({'xml_file': b64encode(self._get_xml_file()).decode("utf-8", "ignore")})

    def _get_SendTestSetAsync_values(self):
        """
        Prepara un conjunto de valores para generar un XML SOAP para un conjunto de pruebas.
        Los valores se obtienen a partir de la información de la compañía asociada al registro actual y del archivo comprimido asociado al registro actual.

        Args:
            self: El registro actual.

        Returns:
            xml_soap_values: Un diccionario con los valores para generar un XML SOAP. Incluye la ruta al archivo de certificado de la compañía, la contraseña del certificado, el nombre del archivo comprimido (sin la extensión .zip), el contenido del archivo comprimido y el identificador del conjunto de pruebas de la compañía.
            Un diccionario con los siguientes elementos:
            - 'Created': La hora de creación en formato UTC y con formato '%Y-%m-%dT%H:%M:%S.001Z'.
            - 'Expires': La hora de expiración, que es 60000 segundos después de la hora de creación, en formato UTC y con formato '%Y-%m-%dT%H:%M:%S.001Z'.
            - 'Id': Un identificador único (UUID).
            - 'BinarySecurityToken': Un token de seguridad binario que se obtiene a partir del certificado proporcionado.
            - fileName: El nombre del archivo comprimido sin la extensión .zip.
            - contentFile: El contenido del archivo comprimido.
            - testSetId: El identificador del conjunto de pruebas de la compañía.
        """
        xml_soap_values = global_functions.get_xml_soap_values(
            self.company_id.certificate_file,
            self.company_id.certificate_password
        )

        xml_soap_values['fileName'] = self.zipped_filename.replace('.zip', '')
        xml_soap_values['contentFile'] = b64encode(self._get_zipped_file()).decode("utf-8", "ignore")
        xml_soap_values['testSetId'] = self.company_id.test_set_id

        return xml_soap_values

    def _get_AcceptedSendTestSetAsync_values(self, accepted_file):
        xml_soap_values = global_functions.get_xml_soap_values(
            self.company_id.certificate_file,
            self.company_id.certificate_password)

        xml_soap_values['fileName'] = self.zipped_filename.replace('.zip', '')
        xml_soap_values['contentFile'] = accepted_file.decode("utf-8", "ignore")
        xml_soap_values['testSetId'] = self.company_id.test_set_id
        return xml_soap_values

    def _get_AcceptedSendBillAsync_values(self, accepted_file):
        xml_soap_values = global_functions.get_xml_soap_values(
            self.company_id.certificate_file,
            self.company_id.certificate_password)

        xml_soap_values['fileName'] = self.zipped_filename.replace('.zip', '')
        xml_soap_values['contentFile'] = accepted_file.decode("utf-8", "ignore")

        return xml_soap_values

    def action_sent_accepted_file(self, accepted_file):
        wsdl = DIAN['wsdl-hab']
        if self.company_id.profile_execution_id == '1':
            wsdl = DIAN['wsdl']
            SendBillAsync_values = self._get_AcceptedSendBillAsync_values(accepted_file)
            SendBillAsync_values['To'] = wsdl.replace('?wsdl', '')
            xml_soap_with_signature = global_functions.get_xml_soap_with_signature(
                global_functions.get_template_xml(SendBillAsync_values, 'SendBillSync'),
                SendBillAsync_values['Id'],
                self.company_id.certificate_file,
                self.company_id.certificate_password)
        else:
            SendTestSetAsync_values = self._get_AcceptedSendTestSetAsync_values(accepted_file)
            SendTestSetAsync_values['To'] = wsdl.replace('?wsdl', '')
            xml_soap_with_signature = global_functions.get_xml_soap_with_signature(
                global_functions.get_template_xml(SendTestSetAsync_values, 'SendTestSetAsync'),
                SendTestSetAsync_values['Id'],
                self.company_id.certificate_file,
                self.company_id.certificate_password)

        response = post(
            wsdl,
            headers={'content-type': 'application/soap+xml;charset=utf-8'},
            data=etree.tostring(xml_soap_with_signature, encoding="unicode"))
        _logger.info(response)
        return True

    def _get_SendBillAsync_values(self):
        """
        Prepara un conjunto de valores para generar un XML SOAP.
        Los valores se obtienen a partir de la información de la compañía asociada al registro actual y del archivo comprimido asociado al registro actual.
        Args:
            self: El registro actual.
        Returns:
            xml_soap_values: Un diccionario con los valores para generar un XML SOAP. Incluye la ruta al archivo de certificado de la compañía, la contraseña del certificado, el nombre del archivo comprimido (sin la extensión .zip) y el contenido del archivo comprimido.
            Un diccionario con los siguientes elementos:
            - Created: La hora de creación en formato UTC y con formato '%Y-%m-%dT%H:%M:%S.001Z'.
            - Expires: La hora de expiración, que es 60000 segundos después de la hora de creación, en formato UTC y con formato '%Y-%m-%dT%H:%M:%S.001Z'.
            - Id: Un identificador único (UUID).
            - BinarySecurityToken: Un token de seguridad binario que se obtiene a partir del certificado proporcionado.
            - fileName: El nombre del archivo comprimido sin la extensión .zip.
            - contentFile: El contenido del archivo comprimido.
        """

        xml_soap_values = global_functions.get_xml_soap_values(
            self.company_id.certificate_file,
            self.company_id.certificate_password
        )

        # Se obtiene el nombre del archivo comprimido sin la extensión .zip.
        xml_soap_values['fileName'] = self.zipped_filename.replace('.zip', '')
        xml_soap_values['contentFile'] = b64encode(self._get_zipped_file()).decode("utf-8", "ignore")

        return xml_soap_values

    def action_sent_zipped_file(self):
        """
        Enviar a la DIAN los documentos, de forma tal que la plataforma DIAN reciba
        y valide los documentos UBL (factura electrónica, nota de crédito y nota de débito) para efectos de obtener un TrackId
        que le permitirá consumir servicio GetStatusZIP para obtener la respuesta de validación para su uso y expedición.

        Args:
            self: El registro actual.
        Returns:
            True: La función siempre devuelve True, independientemente de si el envío fue exitoso o no.
        """
        # if self._get_GetStatus(False):
        #     return True

        msg1 = _("Unknown Error,\nStatus Code: %s,\nReason: %s,\n\nContact with your administrator "
                "or you can choose a journal with a Contingency Checkbook E-Invoicing sequence "
                "and change the Invoice Type to 'Factura por Contingencia Facturador'.")
        msg2 = _("Unknown Error: %s\n\nContact with your administrator "
                "or you can choose a journal with a Contingency Checkbook E-Invoicing sequence "
                "and change the Invoice Type to 'Factura por Contingencia Facturador'.")
        b = "http://schemas.datacontract.org/2004/07/UploadDocumentResponse"
        wsdl = DIAN['wsdl-hab']

        # Si es producción, se envía el archivo comprimido al servicio web de la DIAN.
        if self.company_id.profile_execution_id == '1':
            wsdl = DIAN['wsdl']
            # Se obtiene un conjunto de valores para generar un XML SOAP.
            SendBillAsync_values = self._get_SendBillAsync_values()
            SendBillAsync_values['To'] = wsdl.replace('?wsdl', '')
            # Se genera un XML con firma SOAP.
            xml_soap_with_signature = global_functions.get_xml_soap_with_signature(
                global_functions.get_template_xml(SendBillAsync_values, 'SendBillSync'),
                SendBillAsync_values['Id'],
                self.company_id.certificate_file,
                self.company_id.certificate_password
            )
        else:
            # Si es de pruebas, se envía el archivo comprimido al servicio web de la DIAN.
            # La plantilla es deiferente porque lleva el testSetId.
            SendTestSetAsync_values = self._get_SendTestSetAsync_values()
            SendTestSetAsync_values['To'] = wsdl.replace('?wsdl', '')
            xml_soap_with_signature = global_functions.get_xml_soap_with_signature(
                global_functions.get_template_xml(SendTestSetAsync_values, 'SendTestSetAsync'),
                SendTestSetAsync_values['Id'],
                self.company_id.certificate_file,
                self.company_id.certificate_password
            )

            print(xml_soap_with_signature)
        try:
            _logger.info("**************** Enviando al WS de la DIAN ****************")
            _logger.info("URL: %s" % wsdl)

            xml = etree.tostring(xml_soap_with_signature, encoding="unicode")
            response = post(
                wsdl,
                headers={'content-type': 'application/soap+xml;charset=utf-8'},
                data=xml
            )
            _logger.info("**************** Respuesta del WS de la DIAN ****************")
            #_logger.info("Enviado: %s" % xml)
            _logger.info("Código de estado: %s" % response.status_code)
            _logger.info("Razón: %s" % response.reason)
            _logger.info("Texto: %s" % response.text)

            # Si la respuesta del servicio web es exitosa, se actualiza el estado del registro actual a 'sent' y se procesa la respuesta.
            if response.status_code == 200:
                # Si es producción, se
                if self.company_id.profile_execution_id == '1':
                    # Se actualiza el estado del registro actual a 'sent'.
                    self.write({'state': 'sent'})
                    # Se procesa la respuesta.
                    self._get_status_response(response,send_mail=False)
                else:
                    # Si es de pruebas, se procesa la respuesta.
                    root = etree.fromstring(response.text)

                    for element in root.iter("{%s}ZipKey" % b):
                        self.write({'zip_key': element.text, 'state': 'sent'})
                        self.action_GetStatusZip()
            elif response.status_code in (500, 503, 507):
                dian_document_line_obj = self.env['account.invoice.dian.document.line']
                dian_document_line_obj.create({
                    'dian_document_id': self.id,
                    'send_async_status_code': response.status_code,
                    'send_async_reason': response.reason,
                    'send_async_response': response.text}
                )
            else:
                raise ValidationError(msg1 % (response.status_code, response.reason))
        except exceptions.RequestException as e:
            _logger.info("**************** Error en el envío al WS de la DIAN ****************")
            _logger.info("Error: %s" % e)
            raise ValidationError(msg2 % (e))

        return True

    def sent_zipped_file(self):
        b = "http://schemas.datacontract.org/2004/07/UploadDocumentResponse"

        if self.company_id.profile_execution_id == '1':
            SendBillAsync_values = self._get_SendBillAsync_values()
            xml_soap_with_signature = global_functions.get_xml_soap_with_signature(
                global_functions.get_template_xml(
                    SendBillAsync_values,
                    'SendBillAsync'),
                SendBillAsync_values['Id'],
                self.company_id.certificate_file,
                self.company_id.certificate_password)
        elif self.company_id.profile_execution_id == '2':
            # Obtener el diccionario con los datos del certificado
            SendTestSetAsync_values = self._get_SendTestSetAsync_values()
            # Obtener el XML con la firma
            xml_soap_with_signature = global_functions.get_xml_soap_with_signature(
                global_functions.get_template_xml(
                    SendTestSetAsync_values,
                    'SendTestSetAsync'),
                SendTestSetAsync_values['Id'],
                self.company_id.certificate_file,
                self.company_id.certificate_password
            )

        response = post(
            DIAN['wsdl-hab'],
            headers={'content-type': 'application/soap+xml;charset=utf-8'},
            data=etree.tostring(xml_soap_with_signature, encoding = "unicode")
        )

        if response.status_code == 200:
            root = etree.fromstring(response.text)

            for element in root.iter("{%s}ZipKey" % b):
                self.write({'zip_key': element.text, 'state': 'sent'})
        else:
            raise ValidationError(response.status_code)

    def _get_GetStatusZip_values(self):
        xml_soap_values = global_functions.get_xml_soap_values(
            self.company_id.certificate_file,
            self.company_id.certificate_password)

        xml_soap_values['trackId'] = self.zip_key

        return xml_soap_values

    def _get_GetStatus(self, send_mail):
        msg1 = _("Unknown Error,\nStatus Code: %s,\nReason: %s"
                 "\n\nContact with your administrator.")
        msg2 = _("Unknown Error: %s\n\nContact with your administrator.")
        wsdl = DIAN['wsdl-hab']

        if self.company_id.profile_execution_id == '1':
            wsdl = DIAN['wsdl']

        GetStatus_values = self._get_GetStatus_values()
        GetStatus_values['To'] = wsdl.replace('?wsdl', '')
        xml_soap_with_signature = global_functions.get_xml_soap_with_signature(
            global_functions.get_template_xml(GetStatus_values, 'GetStatus'),
            GetStatus_values['Id'],
            self.company_id.certificate_file,
            self.company_id.certificate_password)

        try:
            response = post(
                wsdl,
                headers={'content-type': 'application/soap+xml;charset=utf-8'},
                data=etree.tostring(xml_soap_with_signature, encoding = "unicode"))

            if response.status_code == 200:
                return self._get_status_response(response, send_mail)
            else:
                raise ValidationError(msg1 % (response.status_code, response.reason))
        except exceptions.RequestException as e:
            raise ValidationError(msg2 % (e))

    def action_GetStatusZip(self):
        wsdl = DIAN['wsdl-hab']

        if self.company_id.profile_execution_id == '1':
            wsdl = DIAN['wsdl']

        GetStatusZip_values = self._get_GetStatusZip_values()
        GetStatusZip_values['To'] = wsdl.replace('?wsdl', '')
        xml_soap_with_signature = global_functions.get_xml_soap_with_signature(
            global_functions.get_template_xml(GetStatusZip_values, 'GetStatusZip'),
            GetStatusZip_values['Id'],
            self.company_id.certificate_file,
            self.company_id.certificate_password)

        xml = etree.tostring(xml_soap_with_signature, encoding = "unicode")
        response = post(
            wsdl,
            headers={'content-type': 'application/soap+xml;charset=utf-8'},
            data=xml
        )

        if response.status_code == 200:
            self._get_status_response(response,send_mail=False)
        else:
            _logger.info("**************** Error en el envío al WS de la DIAN: action_GetStatusZip ****************")
            _logger.info("Enviado: %s" % xml)
            _logger.info("Código de estado: %s" % response.status_code)
            _logger.info("Razón: %s" % response.reason)
            _logger.info("Texto: %s" % response.text)

            raise ValidationError(response.status_code)

        return True

    def GetStatusZip(self):
        b = "http://schemas.datacontract.org/2004/07/DianResponse"
        c = "http://schemas.microsoft.com/2003/10/Serialization/Arrays"
        s = "http://www.w3.org/2003/05/soap-envelope"
        strings = ''
        status_code = 'other'
        GetStatusZip_values = self._get_GetStatusZip_values()
        xml_soap_with_signature = global_functions.get_xml_soap_with_signature(
            global_functions.get_template_xml(
                GetStatusZip_values,
                'GetStatusZip'),
            GetStatusZip_values['Id'],
            self.company_id.certificate_file,
            self.company_id.certificate_password
        )

        xml = etree.tostring(xml_soap_with_signature, encoding = "unicode")
        response = post(
            DIAN['wsdl-hab'],
            headers={'content-type': 'application/soap+xml;charset=utf-8'},
            data=xml
        )

        if response.status_code == 200:
            #root = etree.fromstring(response.content)
            #root = etree.tostring(root, encoding='utf-8')
            root = etree.fromstring(response.content)

            for element in root.iter("{%s}StatusCode" % b):
                if element.text in ('00', '66', '90', '99'):
                    if element.text == '00':
                        self.write({'state': 'done'})

                        if self.invoice_id.move_type == 'out_invoice':
                            self.company_id.out_invoice_sent += 1
                        elif self.invoice_id.move_type == 'out_refund':
                            self.company_id.out_refund_sent += 1
                        elif self.invoice_id.move_type == 'in_refund':
                            self.company_id.in_refund_sent += 1

                    status_code = element.text
            if status_code == '00':
                for element in root.iter("{%s}StatusMessage" % b):
                    strings = element.text

            for element in root.iter("{%s}string" % c):
                if strings == '':
                    strings = '- ' + element.text
                else:
                    strings += '\n\n- ' + element.text

            if strings == '':
                for element in root.iter("{%s}Body" % s):
                    strings = etree.tostring(element, pretty_print=True)

                if strings == '':
                    strings = etree.tostring(root, pretty_print=True)

            self.write({
                'get_status_zip_status_code': status_code,
                'get_status_zip_response': strings})
        else:
            _logger.info("**************** Error en el envío al WS de la DIAN ****************")
            _logger.info("Enviado: %s" % xml)
            _logger.info("Código de estado: %s" % response.status_code)
            _logger.info("Razón: %s" % response.reason)
            _logger.info("Texto: %s" % response.text)

            raise ValidationError(response.status_code)

    def action_reprocess(self):
        self.write({'xml_file': b64encode(self._get_xml_file()).decode("utf-8", "ignore")})
        self.write({'zipped_file': b64encode(self._get_zipped_file()).decode("utf-8", "ignore")})
        self.sent_zipped_file()
        self.GetStatusZip()

    def change_cufe(self):
        if 'procesado anteriormente.' in self.get_status_zip_response and not self.origin_cufe_cude:
            cufe_origin = self.cufe_cude
            new_cufe = self.get_status_zip_response.replace("- Regla: 90, Rechazo: Documento con CUFE '", '').replace("' procesado anteriormente.", '')
            self.origin_cufe_cude = cufe_origin
            self.cufe_cude = new_cufe
        else:
            raise ValidationError('El cufe no ha sido procesado anteriormente')
    
    def return_cufe(self):
        if self.origin_cufe_cude:
            self.cufe_cude = self.origin_cufe_cude
            self.origin_cufe_cude = ''
            

class AccountInvoiceDianDocumentLine(models.Model):
    _name = "account.invoice.dian.document.line"

    dian_document_id = fields.Many2one(
        comodel_name='account.invoice.dian.document',
        string='DIAN Document')
    send_async_status_code = fields.Char(string='Status Code')
    send_async_reason = fields.Char(string='Reason')
    send_async_response = fields.Text(string='Response')