# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S

from odoo import models, fields


class ProductScheme(models.Model):
    _name = 'product.scheme'

    code = fields.Char(string='schemeID')
    name = fields.Char(string='schemeName')
    scheme_agency_id = fields.Char(string='schemeAgencyID')
