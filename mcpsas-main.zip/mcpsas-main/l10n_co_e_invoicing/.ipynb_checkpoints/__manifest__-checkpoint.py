# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S

{
    "name": "Colombian E-Invoicing nbt",
    "category": "Financial",
    "version": "17.0",
    "author" : "NIMBUTECH S.A.S",
    "email": 'desarrollo.odoo@nimbutech.com',
    "website":'https://www.nimbutech.com/',
    'license': 'OPL-1',
    "summary": "Facturación electrónica para Colombia",
    "depends": ['account_debit_note',"l10n_co_dian_data","od_journal_sequence"],
    'external_dependencies': {
        'python': [
            'validators',
            'OpenSSL',
            'xades',
        ],
    },
    "data": [
        'security/ir.model.access.csv',
        "views/account_invoice_views.xml",
        "views/account_invoice_dian_document_views.xml",
        "views/account_journal_views.xml",
        "views/ir_sequence_views.xml",
        "views/res_company_views.xml",
        "views/account_tax_group_views.xml",
        "views/product_template_views.xml",
        "views/account_move_approve.xml",
        "report/account_invoice_report_template.xml",
        "report/account_move_reports.xml",
        "report/account_move_templates.xml",
        "data/product_scheme_data.xml",
        "data/cron_acp_tacita_dian.xml",
        'report/invoice_report.xml',
        'report/pos_invoice_report.xml',
    ],
    "installable": True,
}