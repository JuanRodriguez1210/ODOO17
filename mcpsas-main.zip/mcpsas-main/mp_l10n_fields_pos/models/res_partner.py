# -*- coding: utf-8 -*-
import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class ResPartner(models.Model):
    _inherit = 'res.partner'

    def create(self,vals):
        #for rec in self:
        #Valida si debe configurar información adicional para guardar datos de estado,ciudad y zip automaticos, al igual que dv del nit
        if 'es_pos' in vals:
            City_zip  = self.env['res.city.zip'].search([('id','=',vals['zip_id'])])
            if City_zip:
                zip_city = str(City_zip.name)
                name = str(City_zip.city_id.name)
                vals['city_id'] = City_zip.city_id.id
                vals['state_id'] = City_zip.city_id.state_id.id
                vals['zip'] =  zip_city
                vals['city'] = name
            vals['identification_document'] = vals['vat']
            #valida si es nit
            tipo_de_documento = self.env['res.partner.document.type'].search([('id','=',vals['document_type_id'])])    
            if tipo_de_documento.code == '31':
                check_digit = self._check_dv_pos(str(vals['vat']))
                vals['check_digit'] = check_digit        
            vals.pop('es_pos')
        res = super().create(vals)
        return res

    #Elimina bandera pos
    def write(self,val_list):
        if 'es_pos' in val_list:
             val_list.pop('es_pos')
        res = super().write(val_list)
        return res


    def _check_dv_pos(self, nit):
        """
        Function to calculate the check digit (DV) of the NIT. So there is no
        need to type it manually.
        @param nit: Enter the NIT number without check digit
        @return: String
        """    

        nitString = '0'*(15-len(nit)) + nit
        vl = list(nitString)
        result = (
            int(vl[0])*71 + int(vl[1])*67 + int(vl[2])*59 + int(vl[3])*53 +
            int(vl[4])*47 + int(vl[5])*43 + int(vl[6])*41 + int(vl[7])*37 +
            int(vl[8])*29 + int(vl[9])*23 + int(vl[10])*19 + int(vl[11])*17 +
            int(vl[12])*13 + int(vl[13])*7 + int(vl[14])*3
        ) % 11

        if result in (0, 1):
            return str(result)
        else:
            return str(11-result)