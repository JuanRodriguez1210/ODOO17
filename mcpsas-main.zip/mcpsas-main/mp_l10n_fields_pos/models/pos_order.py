# -*- coding: utf-8 -*-
import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class PosOrder(models.Model):
    _inherit = 'pos.order'


    def _prepare_invoice_vals(self):
        res = super()._prepare_invoice_vals()
        #Agrega el tipo de nota crédito para la fe colombia
        if res:
            if 'move_type' in res:
                if res['move_type'] == 'out_refund':
                    res['refund_type'] = 'credit'
        return res
