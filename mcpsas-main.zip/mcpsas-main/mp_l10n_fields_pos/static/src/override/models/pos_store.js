/** @odoo-module */

import { PosStore } from "@point_of_sale/app/store/pos_store";
import { Order } from "@point_of_sale/app/store/models";
import { patch } from "@web/core/utils/patch";

patch(PosStore.prototype, {
    // @Override
    async _processData(loadedData) {
        await super._processData(...arguments);
        this.fiscal_position_ids = loadedData["account.fiscal.position"];
        this.zip_ids = loadedData["res.city.zip"];
        this.document_type_ids = loadedData["res.partner.document.type"];
        /* if (this.isArgentineanCompany()) {
           
            this.l10n_latam_identification_types = loadedData["l10n_latam.identification.type"];
            this.consumidorFinalAnonimoId = loadedData["consumidor_final_anonimo_id"];
        } */
    },
    
});

/* patch(Order.prototype, {
    setup() {
        super.setup(...arguments);
        if (this.pos.isArgentineanCompany()) {
            if (!this.partner) {
                this.partner = this.pos.db.partner_by_id[this.pos.consumidorFinalAnonimoId];
            }
        }
    },
}); */
