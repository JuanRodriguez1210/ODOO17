/** @odoo-module */

import { _t } from "@web/core/l10n/translation";
import { PartnerDetailsEdit } from "@point_of_sale/app/screens/partner_list/partner_editor/partner_editor";
import { patch } from "@web/core/utils/patch";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";

patch(PartnerDetailsEdit.prototype, {
    setup() {
        super.setup(...arguments);
        this.intFields.push("property_account_position_id");
        this.intFields.push("document_type_id");
        this.intFields.push("zip_id");
        this.changes.property_account_position_id =
            this.props.partner.property_account_position_id &&
            this.props.partner.property_account_position_id[0];
        this.changes.document_type_id =
            this.props.partner.document_type_id &&
            this.props.partner.document_type_id[0];
        this.changes.zip_id =
            this.props.partner.zip_id &&
            this.props.partner.zip_id[0];
        this.changes.person_type =
            this.props.partner.person_type;
        this.changes.es_pos = 1;

        this.changes.firstname = this.props.partner.firstname || "";
        this.changes.othernames = this.props.partner.othernames || "";
        this.changes.lastname = this.props.partner.lastname || "";
        this.changes.lastname2 = this.props.partner.lastname2 || "";

        // Provides translated terms used in the view
        this.partnerDianNames = {
            'firstname': _t('First name'),
            'othernames': _t('Other names'),
            'lastname': _t('Last name'),
            'lastname2': _t('Second last name'),
        };
    },



    //Valida campos obligatorios (vat,mobile)
    saveChanges() {
        const processedChanges = {};
        for (const [key, value] of Object.entries(this.changes)) {
            if (this.intFields.includes(key)) {
                processedChanges[key] = parseInt(value) || false;
            } else {
                processedChanges[key] = value;
            }
        }
        if ((!this.props.partner.vat && !processedChanges.vat) || processedChanges.vat === "") {
            return this.popup.add(ErrorPopup, {
                title: ("El Numero de identificación es obligatorio"),
            });
        }

        //Agrega la info del nombrer en caso de ser persona natural y tener el nombre en otros campos
        if((this.props.person_type || processedChanges.person_type) && processedChanges.person_type === "2" )
        {
            this.props.name = processedChanges.firstname + ' ' + processedChanges.othernames + ' ' + processedChanges.lastname;
            this.changes.name = processedChanges.firstname + ' ' + processedChanges.othernames + ' ' + processedChanges.lastname;
        }

        if ((!this.props.partner.email && !processedChanges.email) || processedChanges.email === "") {
            return this.popup.add(ErrorPopup, {
                title: ("El correo electrónico es obligatorio"),
            });
        }

        if ((!this.props.partner.property_account_position_id && !processedChanges.property_account_position_id) || processedChanges.property_account_position_id === "") {
            return this.popup.add(ErrorPopup, {
                title: ("La posición fiscal es obligatoria"),
            });
        }

        if ((!this.props.partner.person_type && !processedChanges.person_type) || processedChanges.person_type === "") {
            return this.popup.add(ErrorPopup, {
                title: ("El tipo de persona es obligatorio"),
            });
        }
        //Validacions adicionales de la localización para facturqación    
        if ((!this.props.partner.document_type_id && !processedChanges.document_type_id) || processedChanges.document_type_id === "") {
            return this.popup.add(ErrorPopup, {
                title: ("El Tipo de documento es obligatorio"),
            });
        }

        if ((!this.props.partner.zip_id && !processedChanges.zip_id) || processedChanges.zip_id === "") {
            return this.popup.add(ErrorPopup, {
                title: ("La ubicación completa es obligatoria"),
            });
        }

        super.saveChanges(...arguments);

    },
});
