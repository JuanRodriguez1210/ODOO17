/** @odoo-module */

import { PartnerListScreen } from "@point_of_sale/app/screens/partner_list/partner_list";
import { patch } from "@web/core/utils/patch";

patch(PartnerListScreen.prototype, {
    createPartner() {
        super.createPartner(...arguments);
        let pos_bogota = this.pos.zip_ids.findIndex(producto => producto.name === '110111'); 
        if (pos_bogota)
            {     this.state.editModeProps.partner.zip_id = [
                    this.pos.zip_ids[pos_bogota].id,
                    this.pos.zip_ids[pos_bogota].name,
                ]; 
            }
                       
        },
});