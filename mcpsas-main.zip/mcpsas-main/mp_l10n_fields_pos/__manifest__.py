# -*- coding: utf-8 -*-
{
    'name': "mp l10n campos pos",

    'summary': "Agregar los campos de la facturación Electrónica Colombia nbt para el contacto en punto de venta",

    'description': """
    Agregar los campos de la facturación Electrónica Colombia nbt para el contacto en punto de venta:
    - ubicación completa
    - tipo de documento
    - posiciones fiscales
    - tipo de persona
    """,

    'author': "More Products S.A.S.",
    'website': "https://www.odoo.moreproducts.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','point_of_sale','l10n_co_dian_data','mp_pos_edit_partner'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        #'views/views.xml',
        #'views/templates.xml',
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'mp_l10n_fields_pos/static/src/override/models/pos_store.js',
            'mp_l10n_fields_pos/static/src/override/components/partner_editor/*',         
            'mp_l10n_fields_pos/static/src/override/components/partner_list/*',         
        ],
    },
    
}

