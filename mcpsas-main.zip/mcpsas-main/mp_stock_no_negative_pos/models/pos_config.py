from odoo import api, fields, models


class PosConfig(models.Model):
    _inherit = 'pos.config'
     
    minimum_stock_alert = fields.Integer(
        string='Limite minimo para agregar color de alerta en el producto', default=0, readonly=False)
    allow_order_when_product_out_of_stock = fields.Boolean(
        string='Permite realizar orden sin validar stock', default=True, readonly=False)
