
# -*- coding: utf-8 -*-
# @Author: KSOLVES India Private Limited
# @Email: sales@ksolves.com
# @updated v17 By: Nimbutech
# @Email: hugo.gonzalez@nimbutech.com

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    display_stock = fields.Boolean(
        string='Display Stock of products in POS', related='pos_config_id.display_stock', readonly=False)
    minimum_stock_alert = fields.Integer(
        string='Minimum Limit to change the stock color for the product', related='pos_config_id.minimum_stock_alert', readonly=False)
    allow_order_when_product_out_of_stock = fields.Boolean(
        string='Allow Order when Product is Out Of Stock', related='pos_config_id.allow_order_when_product_out_of_stock', readonly=False)

    def write(self, vals):
        print("VALS", vals)
        return super().write(vals)
