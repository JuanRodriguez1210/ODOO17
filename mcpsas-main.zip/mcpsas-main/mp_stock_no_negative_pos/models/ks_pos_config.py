# -*- coding: utf-8 -*-
# @Author: KSOLVES India Private Limited
# @Email: sales@ksolves.com
# @updated v17 By: Nimbutech
# @Email: hugo.gonzalez@nimbutech.com

from odoo import api, fields, models


class PosConfig(models.Model):
    _inherit = 'pos.config'

    display_stock = fields.Boolean(
        string='Display Stock of products in POS', default=True, readonly=False)
    minimum_stock_alert = fields.Integer(
        string='Minimum Limit to change the stock color for the product', default=0, readonly=False)
    allow_order_when_product_out_of_stock = fields.Boolean(
        string='Allow Order when Product is Out Of Stock', default=True, readonly=False)
