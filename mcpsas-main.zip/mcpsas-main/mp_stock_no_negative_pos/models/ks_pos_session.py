# -*- coding: utf-8 -*-
# @Author: KSOLVES India Private Limited
# @Email: sales@ksolves.com
# @updated v17 By: Nimbutech
# @Email: hugo.gonzalez@nimbutech.com

from odoo import api, fields, models

class PosSession(models.Model):
    _inherit = 'pos.session'

    def _loader_params_product_product(self):
        res = super(PosSession, self)._loader_params_product_product()
        res['search_params']['fields'].append('qty_available')
        return res