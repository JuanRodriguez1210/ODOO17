from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'
   
    minimum_stock_alert = fields.Integer(
        string='Limite minimo para agregar color de alerta en el producto', related='pos_config_id.minimum_stock_alert', readonly=False)
    allow_order_when_product_out_of_stock = fields.Boolean(
        string='Permite realizar orden sin validar stock', related='pos_config_id.allow_order_when_product_out_of_stock', readonly=False)

    def write(self, vals):
        print("VALS", vals)
        return super().write(vals)
