# -*- coding: utf-8 -*-
{
    'name': "Stock no negativo pos",
    'summary': """Permite agregar validación al stock de los productos que se venden desde el punto de venta.""",
    'description': """
        Agrega alertas de la cantidad de producto disponible, así como inhabilita la selección del producto si no se tiene en inventario,
        Se puede editar la cantidad a validar desde los ajustes del punto de venta.
    """,
    'author': "More Products S.A.S.",
    'website': "https://www.odoo.moreproducts.com",    
    'category': 'Point Of Sale',   
    'version': '17.0',    
    'depends': ['point_of_sale'],
    'data': [
        'views/res_config_settings.xml',
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'mp_stock_no_negative_pos/static/src/app/**/*',
        ],
    }
}
