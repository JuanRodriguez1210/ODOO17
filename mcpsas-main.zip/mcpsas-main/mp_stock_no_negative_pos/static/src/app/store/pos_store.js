/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/store/pos_store";

patch(PosStore.prototype, {
    async addProductToCurrentOrder(product, options = {}) {
        const allow_order_when_product_out_of_stock = this.config.allow_order_when_product_out_of_stock;
        if (!allow_order_when_product_out_of_stock && product.qty_available <= 0) {
            return;
        }
        return super.addProductToCurrentOrder(...arguments);
    }
});