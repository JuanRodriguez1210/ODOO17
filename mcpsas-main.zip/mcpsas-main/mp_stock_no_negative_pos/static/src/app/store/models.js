/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { Order } from "@point_of_sale/app/store/models";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { _t, _lt } from "@web/core/l10n/translation";
import { sprintf } from "@web/core/utils/strings";

patch(Order.prototype, {

    validate_order_items_availability() {
        var isValid = true, error_order_line = null;
        const allow_order_when_product_out_of_stock = this.pos.config.allow_order_when_product_out_of_stock;

        if (!allow_order_when_product_out_of_stock) {
            for (var i = 0; i < this.orderlines.length; i++) {
                const order_line = this.orderlines[i];
                if (order_line.quantity > order_line.product.qty_available) {
                    isValid = false;
                    error_order_line = order_line;
                    break;
                }
            }
        }
        if (!isValid) {
            this.env.services.popup.add(ErrorPopup, {
                title: _t('No se puede pedir un producto más allá de su disponibilidad'),
                body: sprintf(_t('%s  tienes  %s items disponibles. \n estas tratando de ordenar %s.'), error_order_line.product.display_name, error_order_line.product.qty_available, error_order_line.quantity)
            });
        }
        return isValid;
    },


    async pay() {
        const isValid = this.validate_order_items_availability();
        if (!isValid) return;
        return super.pay(...arguments);
    }
});
