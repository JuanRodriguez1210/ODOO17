/** @odoo-module */

import { ProductCard } from "@point_of_sale/app/generic_components/product_card/product_card";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { patch } from "@web/core/utils/patch";

patch(ProductCard.prototype, {
    setup() {
        super.setup();
        this.pos = usePos();
        
    },
    availableStock(product_id) {
        return this.pos.db.product_by_id[product_id].qty_available;
    },
    get minimumStock() {
        return this.pos.config.minimum_stock_alert;
    },
    get allow_order_when_product_out_of_stock() {
        return this.pos.config.allow_order_when_product_out_of_stock;
    }
});
