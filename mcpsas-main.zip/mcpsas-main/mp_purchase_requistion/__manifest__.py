# -*- coding: utf-8 -*-
{
    'name': "Mp Acuerdos de Compras",
    'summary': "Mp Acuerdos de Compras",
    'description': """
            Mp Acuerdos de Compras
    """,
    'author': "More Products S.A.S.",
    'website': "https://www.odoo.moreproducts.com",
    'category': 'Account',
    'version': '0.1',
    'depends': [
        'base',
        'account_accountant',
        'purchase_requisition',
        ],
    'data': [
        # 'security/ir.model.access.csv',
        'views/account_analytic_views.xml',
        'views/purchase_requisition_views.xml',
    ],
}

