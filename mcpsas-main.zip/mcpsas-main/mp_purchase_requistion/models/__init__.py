# -*- coding: utf-8 -*-

from . import account_analytic
from . import purchase_requisition
