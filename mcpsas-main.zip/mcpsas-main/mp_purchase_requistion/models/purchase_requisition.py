# -*- encoding: utf-8 -*-

from datetime import datetime, time

from odoo import api, fields, models, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)

PURCHASE_REQUISITION_LINE_STATES = [
    ('undefined', 'Indefinido'),
    ('accepted', 'Aceptado'),
    ('rejected', 'Rechazado'),
    ('quoted', 'Cotizado'),
    ('purchase', 'Comprado'),
]


PURCHASE_REQUISITION_STATES = [
    ('draft', 'Draft'),
    ('ongoing', 'Ongoing'),
    ('in_approval', 'En Aprobación'),
    ('in_progress', 'Confirmed'),
    ('open', 'Bid Selection'),
    ('done', 'Closed'),
    ('cancel', 'Cancelled')
]

class PurchaseRequisition(models.Model):
    _inherit = "purchase.requisition"

    

    account_analytic_id = fields.Many2one('account.analytic.account', string='Proyecto')
    state = fields.Selection(selection_add=[('in_approval', 'En Aprobación'), ('ongoing',)], ondelete={'in_approval': 'cascade'})
    state_blanket_order = fields.Selection(PURCHASE_REQUISITION_STATES, compute='_set_state')

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _("New")) == _("New"):
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'purchase.requisition.blanket.order') or _("New")
        
        return super().create(vals_list) 


    def action_in_approval(self):
        self.ensure_one()
        if not self.line_ids:
            raise UserError("You cannot confirm agreement '%s' because there is no product line.")
        self.write({'state': 'in_approval'})

        for line in self.line_ids:
            line_obj = self.env['purchase.requisition.line'].browse(line.id)
            if line_obj:
                line_obj.write({'qty_approved': line_obj.product_qty})
                
                
    def action_in_progress(self):
        self.ensure_one()
        
        if not self.account_analytic_id:
            raise UserError(_("Debe seleccionar un proyecto!", self.name))
        if not self.account_analytic_id.user_ids.ids:
            raise UserError("El proyecto seleccionado no tiene definido un responsable!.")
        
        if self.env.uid not in self.account_analytic_id.user_ids.ids:
            raise UserError("Para pasar a Aprobación debe ser el encargado del proyecto!.")
            
        for requisition_line in self.line_ids:
            if requisition_line.state == 'undefined':
                raise UserError('Ninguna línea puede quedar en estado indefinido')
        
        rec = super(PurchaseRequisition, self).action_in_progress()
        return rec
    
    def action_all_accepted(self):
        if not self.account_analytic_id:
            raise UserError(_("Debe seleccionar un proyecto!"))
        if not self.account_analytic_id.user_ids.ids:
            raise UserError("El proyecto seleccionado no tiene definido un responsable!.")

        if self.env.uid not in self.account_analytic_id.user_ids.ids:
            raise UserError("Para pasar a Aprobación debe ser el encargado del proyecto!.")
            
        for line in self.line_ids:
            line.write({
                'state': 'accepted'
            })
        return

    def action_all_rejected(self):
        if not self.account_analytic_id:
            raise UserError(_("Debe seleccionar un proyecto!", self.name))
        if not self.account_analytic_id.user_ids.ids:
            raise UserError("El proyecto seleccionado no tiene definido un responsable!.")
        
        if self.env.uid not in self.account_analytic_id.user_ids.ids:
            raise UserError("Para pasar a Aprobación debe ser el encargado del proyecto!.")

        for line in self.line_ids:
            line.write({
                'state': 'rejected'
            })
        return
    

class PurchaseRequisitionLine(models.Model):
    _inherit = "purchase.requisition.line"

    price_unit = fields.Float('Precio Unitario', required=False)
    qty_approved = fields.Float('Cantidad Aprobada')
    state = fields.Selection(PURCHASE_REQUISITION_LINE_STATES,
                            'Estado',required=True,
                            copy=False, default='undefined')
