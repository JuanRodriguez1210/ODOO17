# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S
from . import controllers
from . import models
from . import wizards
from .hooks import post_init_hook