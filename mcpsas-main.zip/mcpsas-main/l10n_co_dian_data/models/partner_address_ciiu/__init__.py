from . import address_code
from . import street_code
from . import ciiu_value
from . import res_partner