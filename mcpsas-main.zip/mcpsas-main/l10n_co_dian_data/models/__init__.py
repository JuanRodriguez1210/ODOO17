# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S
from . import l10n_co_account_fiscal_position_party_tax_scheme
from . import l10n_co_account_invoice_discrepancy_response
from . import l10n_co_account_invoice_payment_mean
from . import l10n_co_account_tax_group_type
from . import l10n_co_base_location
from . import l10n_co_partner_person_type
from . import l10n_co_partner_vat
from . import l10n_co_sequence_resolution
from . import partner_commercial_name
from . import l10n_co_account_fiscal_position_listname
from . import l10n_co_product_uom
from . import partner_address_ciiu