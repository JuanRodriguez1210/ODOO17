# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S

from . import account_tax_group_type
from . import account_tax_group
