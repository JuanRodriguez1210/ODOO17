# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S

from . import res_partner_document_type
from . import res_partner
