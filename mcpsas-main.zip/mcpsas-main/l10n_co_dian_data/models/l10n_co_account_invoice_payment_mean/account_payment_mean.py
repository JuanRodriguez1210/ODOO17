# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S

from odoo import fields, models, _

class AccountPaymentMean(models.Model):
	_name = 'account.payment.mean'
	_description = 'Ways to pay'

	name = fields.Char(string='Name', required=True, translate=True)
	code = fields.Char(string='Code', required=True)

	_sql_constraints = [
		('name_unique', 'unique(name)', _("The name must be unique")),
		('code_unique', 'unique(code)', _("The code must be unique"))]
