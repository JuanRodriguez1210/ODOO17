# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S
from . import (
    res_city_zip,
    res_country,
    res_partner,
    res_company,
    res_city,
)
