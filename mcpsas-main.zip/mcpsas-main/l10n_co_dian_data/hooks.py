
from odoo import SUPERUSER_ID, api


def post_init_hook(env):
    env["res.partner"]._install_partner_firstname()
