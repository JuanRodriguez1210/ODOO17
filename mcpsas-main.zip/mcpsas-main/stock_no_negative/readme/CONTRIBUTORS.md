- Alexis de Lattre \<<alexis.delattre@akretion.com>\>

- Vishnu Vanneri \<<vanneri.odoodev@gmail.com>\>

- Serpent Consulting Services Pvt. Ltd. \<<support@serpentcs.com>\>

- [ForgeFlow S.L.](contact@forgeflow.com):
  - Jordi Ballester
  - Joan Mateu

- [Tecnativa](https://www.tecnativa.com):
  - Pedro M. Baeza

- [Spacefoot](https://www.spacefoot.com):
  - Quentin Delcourte

- Vishnu Vanneri \<<vvanneri@ioppolo.com.au>\>

- [OERP Canada](https://www.oerp.ca/):
  - Foram Darji \<<fd@oerp.ca>\>
