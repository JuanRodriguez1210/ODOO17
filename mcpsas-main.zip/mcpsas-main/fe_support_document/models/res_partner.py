# -*- coding: utf-8 -*-
# Copyright 2024 NIMBUTECH S.A.S


from odoo import api, models, fields, _
from odoo.exceptions import UserError
import logging
class ResPartner(models.Model):
    _inherit = "res.partner"

    #Agrega digito de verificación siempre al partner
    def _get_accounting_partner_party_values(self, company_id):
        values = super(ResPartner, self)._get_accounting_partner_party_values(company_id)
        dv_partner_ds = self._check_dv_ds(self.identification_document)
        values['dv_partner_ds'] = dv_partner_ds
        return values

    def _check_dv_ds(self, nit):
        """
        Function to calculate the check digit (DV) of the NIT. So there is no
        need to type it manually.
        @param nit: Enter the NIT number without check digit
        @return: String
        """
        #se sobreescribe la función ya que para facturas no lo hace cuando no sea nit
        for item in self:

            nitString = '0' * (15 - len(nit)) + nit
            vl = list(nitString)
            result = (
                             int(vl[0]) * 71 + int(vl[1]) * 67 + int(vl[2]) * 59 + int(vl[3]) * 53 +
                             int(vl[4]) * 47 + int(vl[5]) * 43 + int(vl[6]) * 41 + int(vl[7]) * 37 +
                             int(vl[8]) * 29 + int(vl[9]) * 23 + int(vl[10]) * 19 + int(vl[11]) * 17 +
                             int(vl[12]) * 13 + int(vl[13]) * 7 + int(vl[14]) * 3
                     ) % 11

            if result in (0, 1):
                return str(result)
            else:
                return str(11 - result)