# -*- coding: utf-8 -*-

from . import account_journal
from . import account_invoice
from . import account_invoice_dian_document
from . import res_partner