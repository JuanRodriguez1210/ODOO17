# -*- coding: utf-8 -*-

from . import account_advance_payment
from . import res_partner_bank
