# -*- coding: utf-8 -*-
{
    "name": "Colombian E-Invoicing",
    'summary': 'Módulo que agrega información de facturación electrónica  en el ticket pos.',
    'description': """
- Agrega los datos del cufe, número de factura y qr de factura electrónica al ticket pos., Además de modificaciones en la estructura original del ticket.
    """,
    "version": "17.0",
    'author': "More Products S.A.S.",
    'website': "https://www.odoo.moreproducts.com",
    'category': 'Financial',
    'depends': ['l10n_co_e_invoicing'],
    'data': [
        'views/account_invoice_dian_document_views.xml'
    ],
    'assets': {
    },
    'application': False,
    'installable': True,
    "license": "LGPL-3",
}
