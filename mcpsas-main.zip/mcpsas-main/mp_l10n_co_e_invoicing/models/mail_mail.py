# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class MailMail(models.Model):
    _inherit = "mail.mail"

    invoice_dian_document_id = fields.Many2one('account.invoice.dian.document', 'Invoice DIAN Document')