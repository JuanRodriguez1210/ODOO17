# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
import xml.etree.ElementTree as ET
from io import BytesIO
import zipfile
from zipfile import ZipFile
from odoo.addons.l10n_co_e_invoicing.models import global_functions
from base64 import b64encode, b64decode
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class AccountInvoiceDianDocument(models.Model):
    _inherit = "account.invoice.dian.document"

    mail_ids = fields.One2many(
        'mail.mail', 'invoice_dian_document_id', 'Mails', readonly=True)

    def _get_zipped_file(self):
        """
        Comprime el archivo XML con firma y lo devuelve como un conjunto de bytes.
        """
        output = BytesIO()
        zipfile = ZipFile(output, mode='w')
        zipfile_content = BytesIO()
        zipfile_content.write(b64decode(self.xml_file))

        # Añadir el archivo PDF
        pdf_content = BytesIO()
        pdf_content.write(b64decode(b64encode(self._get_pdf_file())))
        zipfile.writestr(self.xml_filename.replace(
            '.xml', '.pdf'), pdf_content.getvalue())

        zipfile.writestr(self.xml_filename, zipfile_content.getvalue())
        zipfile.close()
        
        return output.getvalue()

    def action_send_mail(self):
        # OVERRIDE
        try:
            msg = _("Your invoice has not been validated")
            template_id = self.env.ref('l10n_co_e_invoicing.email_template_for_einvoice').id
            template = self.env['mail.template'].browse(template_id)

            if not self.invoice_id.name:
                raise UserError(msg)

            buff = BytesIO()
            zip_file = zipfile.ZipFile(buff, mode='w')
            msg ='259'
            xml_attachment_file = False
            if self.ar_xml_file and self.xml_file:
                # Se genera el xml tipo adjunto
                xml_without_signature = global_functions.get_template_xml(self._get_attachment_values(), 'attachment')
                # Se guarda el xml tipo adjunto
                xml_attachment_file = self.env['ir.attachment'].create({
                    'name': self.xml_filename,
                    'type': 'binary',
                    'datas': b64encode(xml_without_signature.encode()).decode("utf-8", "ignore")}
                )

            # Se comprime el xml tipo adjunto
            if xml_attachment_file:
                zip_content = BytesIO()
                zip_content.write(
                    b64decode(b64encode(xml_without_signature.encode()).decode("utf-8", "ignore")))
                zip_file.writestr(self.xml_filename, zip_content.getvalue())
            msg = '277'
            zip_content = BytesIO()
            # Se comprime la factura en pdf
            zip_content.write(b64decode(b64encode(self._get_pdf_file())))
            msg = '281'
            # Se comprime el contenido del primer zip en el zip principal
            zip_file.writestr(self.xml_filename.replace('.xml', '.pdf'), zip_content.getvalue())
            msg = '283'
            zip_file.close()
            zipped_file = b64encode(buff.getvalue())
            buff.close()
            msg = '287'
            # Se crea un archivo zip con el xml tipo adjunto y la factura en pdf
            attachment = self.env['ir.attachment'].create({
                'name': self.xml_filename.replace('.xml', '.zip'),
                'type': 'binary',
                'datas': zipped_file,
            })
            msg = '294'
            attach_ids = [attachment.id]
            #no aplica
            """ edi_attachment_ids = self.invoice_id.edi_attachment_ids

            # añade los adjuntos edi a los adjuntos del correo
            if edi_attachment_ids:
                attach_ids += edi_attachment_ids.ids """

            # Si es una factura de venta o una factura de exportación se adjunta el adjunto a la plantilla de correo
            if self.invoice_id.invoice_type_code in ('01', '02'):
                template.attachment_ids = [(6, 0, attach_ids)]
            else:
                template.attachment_ids = [(6, 0, attach_ids)]

            template.attachment_ids = [(6, 0, attach_ids)]
            # Se envia el correo con el adjunto
            mail_id = template.send_mail(self.invoice_id.id, force_send=True)
            mail = self.env['mail.mail'].browse(mail_id)
            mail.invoice_dian_document_id = self.id
            self.write({'mail_sent': True, 'mail_id': mail_id})
        except Exception as e:
            _logger.error("Error enviando correo : %s , en la linea %s", e, msg)
        return True
